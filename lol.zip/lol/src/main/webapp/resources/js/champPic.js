let champName = document.getElementById("champName").childNodes[0].nodeValue;

let pic = document.getElementById("cPic");

//let passivePic = document.getElementById("passivePic"),
//	passiveDes = document.getElementById("passiveDes"),
//	passivePic2 = document.getElementById("passivePic2"),
//	passiveDes2 = document.getElementById("passiveDes2");

if(champName=="가렌") {
    pic.innerHTML='<img src="/lol/resources/img/champ/Garen.jpg">'
}
else if(champName=="갈리오") {
    pic.innerHTML='<img src="/lol/resources/img/champ/Galio.jpg">'
}
else if(champName=="루시안") {
	pic.innerHTML='<img src="/lol/resources/img/champ/Lucian.jpg">'
}
else if(champName=="아칼리") {
    pic.innerHTML='<img src="/lol/resources/img/champ/Akali.jpg">'
}
else if(champName=="잔나") {
	pic.innerHTML='<img src="/lol/resources/img/champ/Janna.jpg">'
}