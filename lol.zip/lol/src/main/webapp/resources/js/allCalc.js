function allCalc() {
	let champName = document.getElementById("champName").childNodes[0].nodeValue;
	let hp2 = Number(document.getElementById('hp2').childNodes[0].nodeValue),
    hpRecovery2 = Number(document.getElementById('hpRecovery2').childNodes[0].nodeValue),
   	resources2 = Number(document.getElementById('resources2').childNodes[0].nodeValue),
   	resourcesRecovery2 = Number(document.getElementById('resourcesRecovery2').childNodes[0].nodeValue),
   	attack2 = Number(document.getElementById('attack2').childNodes[0].nodeValue),
   	attackSpeed2 = Number(document.getElementById('attackSpeed2').childNodes[0].nodeValue),
   	defense2 = Number(document.getElementById('defense2').childNodes[0].nodeValue),
   	magicDefense2 = Number(document.getElementById('magicDefense2').childNodes[0].nodeValue),
   	range2 = Number(document.getElementById('range2').childNodes[0].nodeValue),
   	speed2 = Number(document.getElementById('speed2').childNodes[0].nodeValue),
   	spell2 = Number(document.getElementById('spell2').childNodes[0].nodeValue);
		
let ihp1 = Number(document.getElementById('ihp1').childNodes[0].nodeValue),
	ihpRecovery1 = Number(document.getElementById('ihpRecovery1').childNodes[0].nodeValue),
	ihpRecovery5s1 = Number(document.getElementById('ihpRecovery5s1').childNodes[0].nodeValue),
	imp1 = Number(document.getElementById('imp1').childNodes[0].nodeValue),
	impRecovery1 = Number(document.getElementById('impRecovery1').childNodes[0].nodeValue),
	impRecovery5s1 = Number(document.getElementById('impRecovery5s1').childNodes[0].nodeValue),
	iattack1 = Number(document.getElementById('iattack1').childNodes[0].nodeValue),
	iattackSpeed1 = Number(document.getElementById('iattackSpeed1').childNodes[0].nodeValue),
	idefense1 = Number(document.getElementById('idefense1').childNodes[0].nodeValue),
	imagicDefense1 = Number(document.getElementById('imagicDefense1').childNodes[0].nodeValue),
	ispell1 = Number(document.getElementById('ispell1').childNodes[0].nodeValue),
	icoolDown1 = Number(document.getElementById('icoolDown1').childNodes[0].nodeValue),
	ispeed1 = Number(document.getElementById('ispeed1').childNodes[0].nodeValue),
	ispellUp1 = Number(document.getElementById('ispellUp1').childNodes[0].nodeValue),
	ispeedUp1 = Number(document.getElementById('ispeedUp1').childNodes[0].nodeValue);

let ihp2 = Number(document.getElementById('ihp2').childNodes[0].nodeValue),
	ihpRecovery2 = Number(document.getElementById('ihpRecovery2').childNodes[0].nodeValue),
	ihpRecovery5s2 = Number(document.getElementById('ihpRecovery5s2').childNodes[0].nodeValue),
	imp2 = Number(document.getElementById('imp2').childNodes[0].nodeValue),
	impRecovery2 = Number(document.getElementById('impRecovery2').childNodes[0].nodeValue),
	impRecovery5s2 = Number(document.getElementById('impRecovery5s2').childNodes[0].nodeValue),
	iattack2 = Number(document.getElementById('iattack2').childNodes[0].nodeValue),
	iattackSpeed2 = Number(document.getElementById('iattackSpeed2').childNodes[0].nodeValue),
	idefense2 = Number(document.getElementById('idefense2').childNodes[0].nodeValue),
	imagicDefense2 = Number(document.getElementById('imagicDefense2').childNodes[0].nodeValue),
	ispell2 = Number(document.getElementById('ispell2').childNodes[0].nodeValue),
	icoolDown2 = Number(document.getElementById('icoolDown2').childNodes[0].nodeValue),
	ispeed2 = Number(document.getElementById('ispeed2').childNodes[0].nodeValue),
	ispellUp2 = Number(document.getElementById('ispellUp2').childNodes[0].nodeValue),
	ispeedUp2 = Number(document.getElementById('ispeedUp2').childNodes[0].nodeValue);

let ihp3 = Number(document.getElementById('ihp3').childNodes[0].nodeValue),
	ihpRecovery3 = Number(document.getElementById('ihpRecovery3').childNodes[0].nodeValue),
	ihpRecovery5s3 = Number(document.getElementById('ihpRecovery5s3').childNodes[0].nodeValue),
	imp3 = Number(document.getElementById('imp3').childNodes[0].nodeValue),
	impRecovery3 = Number(document.getElementById('impRecovery3').childNodes[0].nodeValue),
	impRecovery5s3 = Number(document.getElementById('impRecovery5s3').childNodes[0].nodeValue),
	iattack3 = Number(document.getElementById('iattack3').childNodes[0].nodeValue),
	iattackSpeed3 = Number(document.getElementById('iattackSpeed3').childNodes[0].nodeValue),
	idefense3 = Number(document.getElementById('idefense3').childNodes[0].nodeValue),
	imagicDefense3 = Number(document.getElementById('imagicDefense3').childNodes[0].nodeValue),
	ispell3 = Number(document.getElementById('ispell3').childNodes[0].nodeValue),
	icoolDown3 = Number(document.getElementById('icoolDown3').childNodes[0].nodeValue),
	ispeed3 = Number(document.getElementById('ispeed3').childNodes[0].nodeValue),
	ispellUp3 = Number(document.getElementById('ispellUp3').childNodes[0].nodeValue),
	ispeedUp3 = Number(document.getElementById('ispeedUp3').childNodes[0].nodeValue);

let ihp4 = Number(document.getElementById('ihp4').childNodes[0].nodeValue),
	ihpRecovery4 = Number(document.getElementById('ihpRecovery4').childNodes[0].nodeValue),
	ihpRecovery5s4 = Number(document.getElementById('ihpRecovery5s4').childNodes[0].nodeValue),
	imp4 = Number(document.getElementById('imp4').childNodes[0].nodeValue),
	impRecovery4 = Number(document.getElementById('impRecovery4').childNodes[0].nodeValue),
	impRecovery5s4 = Number(document.getElementById('impRecovery5s4').childNodes[0].nodeValue),
	iattack4 = Number(document.getElementById('iattack4').childNodes[0].nodeValue),
	iattackSpeed4 = Number(document.getElementById('iattackSpeed4').childNodes[0].nodeValue),
	idefense4 = Number(document.getElementById('idefense4').childNodes[0].nodeValue),
	imagicDefense4 = Number(document.getElementById('imagicDefense4').childNodes[0].nodeValue),
	ispell4 = Number(document.getElementById('ispell4').childNodes[0].nodeValue),
	icoolDown4 = Number(document.getElementById('icoolDown4').childNodes[0].nodeValue),
	ispeed4 = Number(document.getElementById('ispeed4').childNodes[0].nodeValue),
	ispellUp4 = Number(document.getElementById('ispellUp4').childNodes[0].nodeValue),
	ispeedUp4 = Number(document.getElementById('ispeedUp4').childNodes[0].nodeValue);

let ihp5 = Number(document.getElementById('ihp5').childNodes[0].nodeValue),
	ihpRecovery5 = Number(document.getElementById('ihpRecovery5').childNodes[0].nodeValue),
	ihpRecovery5s5 = Number(document.getElementById('ihpRecovery5s5').childNodes[0].nodeValue),
	imp5 = Number(document.getElementById('imp5').childNodes[0].nodeValue),
	impRecovery5 = Number(document.getElementById('impRecovery5').childNodes[0].nodeValue),
	impRecovery5s5 = Number(document.getElementById('impRecovery5s5').childNodes[0].nodeValue),
	iattack5 = Number(document.getElementById('iattack5').childNodes[0].nodeValue),
	iattackSpeed5 = Number(document.getElementById('iattackSpeed5').childNodes[0].nodeValue),
	idefense5 = Number(document.getElementById('idefense5').childNodes[0].nodeValue),
	imagicDefense5 = Number(document.getElementById('imagicDefense5').childNodes[0].nodeValue),
	ispell5 = Number(document.getElementById('ispell5').childNodes[0].nodeValue),
	icoolDown5 = Number(document.getElementById('icoolDown5').childNodes[0].nodeValue),
	ispeed5 = Number(document.getElementById('ispeed5').childNodes[0].nodeValue),
	ispellUp5 = Number(document.getElementById('ispellUp5').childNodes[0].nodeValue),
	ispeedUp5 = Number(document.getElementById('ispeedUp5').childNodes[0].nodeValue);

let ihp6 = Number(document.getElementById('ihp6').childNodes[0].nodeValue),
	ihpRecovery6 = Number(document.getElementById('ihpRecovery6').childNodes[0].nodeValue),
	ihpRecovery5s6 = Number(document.getElementById('ihpRecovery5s6').childNodes[0].nodeValue),
	imp6 = Number(document.getElementById('imp6').childNodes[0].nodeValue),
	impRecovery6 = Number(document.getElementById('impRecovery6').childNodes[0].nodeValue),
	impRecovery5s6 = Number(document.getElementById('impRecovery5s6').childNodes[0].nodeValue),
	iattack6 = Number(document.getElementById('iattack6').childNodes[0].nodeValue),
	iattackSpeed6 = Number(document.getElementById('iattackSpeed6').childNodes[0].nodeValue),
	idefense6 = Number(document.getElementById('idefense6').childNodes[0].nodeValue),
	imagicDefense6 = Number(document.getElementById('imagicDefense6').childNodes[0].nodeValue),
	ispell6 = Number(document.getElementById('ispell6').childNodes[0].nodeValue),
	icoolDown6 = Number(document.getElementById('icoolDown6').childNodes[0].nodeValue),
	ispeed6 = Number(document.getElementById('ispeed6').childNodes[0].nodeValue),
	ispellUp6 = Number(document.getElementById('ispellUp6').childNodes[0].nodeValue),
	ispeedUp6 = Number(document.getElementById('ispeedUp6').childNodes[0].nodeValue);

let hp3 = document.getElementById('hp3'),
	hpRecovery3 = document.getElementById('hpRecovery3'),
	resources3 = document.getElementById('resources3'),
	resourcesRecovery3 = document.getElementById('resourcesRecovery3'),
	attack3 = document.getElementById('attack3'),
	attackSpeed3 = document.getElementById('attackSpeed3'),
	defense3 = document.getElementById('defense3'),
	magicDefense3 = document.getElementById('magicDefense3'),
	range3 = document.getElementById('range3'),
	speed3 = document.getElementById('speed3'),
	spell3 = document.getElementById('spell3'),
	coolDown3 = document.getElementById('coolDown3');

hp3.innerHTML = hp2+ihp1+ihp2+ihp3+ihp4+ihp5+ihp6;
hpRecovery3.innerHTML = hpRecovery2*(1+ihpRecovery1+ihpRecovery2+ihpRecovery3
		+ihpRecovery4+ihpRecovery5+ihpRecovery6)+ihpRecovery5s1+ihpRecovery5s2
		+ihpRecovery5s3+ihpRecovery5s4+ihpRecovery5s5+ihpRecovery5s6;
resources3.innerHTML = resources2+imp1+imp2+imp3+imp4+imp5+imp6;
resourcesRecovery3.innerHTML = resourcesRecovery2*(1+impRecovery1+impRecovery2+impRecovery3
		+impRecovery4+impRecovery5+impRecovery6)+impRecovery5s1+impRecovery5s2
		+impRecovery5s3+impRecovery5s4+impRecovery5s5+impRecovery5s6;
attack3.innerHTML = attack2+iattack1+iattack2+iattack3+iattack4+iattack5+iattack6;
attackSpeed3.innerHTML = attackSpeed2*(1+iattackSpeed1+iattackSpeed2+iattackSpeed3
		+iattackSpeed4+iattackSpeed5+iattackSpeed6);
defense3.innerHTML = defense2+idefense1+idefense2+idefense3+idefense4+idefense5+idefense6;
magicDefense3.innerHTML = magicDefense2+imagicDefense1+imagicDefense2+imagicDefense3+imagicDefense4
		+imagicDefense5+imagicDefense6;
range3.innerHTML = range2;
speed3.innerHTML = (speed2+ispeed1+ispeed2+ispeed3+ispeed4+ispeed5+ispeed6)*(1+ispeedUp1+ispeedUp2+ispeedUp3+ispeedUp4+ispeedUp5+ispeedUp6);
spell3.innerHTML = (spell2+ispell1+ispell2+ispell3+ispell4+ispell5+ispell6)*(1+ispellUp1+ispellUp2+ispellUp3+ispellUp4+ispellUp5+ispellUp6);
coolDown3.innerHTML = icoolDown1+icoolDown2+icoolDown3+icoolDown4+icoolDown5+icoolDown6;

if(champName=="아칼리"||champName=="가렌") {
	resources3.innerHTML = resources2;
	resourcesRecovery3.innerHTML = resourcesRecovery2;
}
}


