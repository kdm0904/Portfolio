let items = [
	{item:"강철의 솔라리 펜던트", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		mpRecovery5s:0, attack:0, attackSpeed:0, defense:30, magicDefense:65,
		spell:0, coolDown:0, speed:0, spellUp:0, speedUp:0, 
		passiveEffect:"없음",
		activeEffect:"2.5초간 근처 아군들을 보호막으로 감싸 최대 120 (+ 레벨 당 +10) (+추가 체력의 20%)에 해당하는 피해를 흡수합니다. (재사용 대기시간 120초) 레벨당 보호막 흡수량은 자기 자신과 대상 중 더 높은 쪽을 기준으로 합니다. 보호막 흡수량의 추가 체력 비례 %는 자신의 레벨을 기준으로 합니다. 대상이 지난 20초 안에 다른 챔피언에게서 강철의 솔라리 펜던트 효과를 얻은 경우 효과가 75% 감소합니다."
	},
	{item:"고속 연사포", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		mpRecovery5s:0, attack:0, attackSpeed:0.3, defense:0, magicDefense:0,
		spell:0, coolDown:0, speed:0, spellUp:0, speedUp:0.05, 
		passiveEffect:"충전 상태: 이동하거나 공격하면 충전 상태가 됩니다./ 저격수: 충전 상태로 공격 시 120의 추가 마법 피해를 입히며 사거리가 35% 증가합니다. (최대 사거리 +150)/ 치명타 확률 +25%, 이동 속도 +5%",
		activeEffect:"없음"
	},
	{item:"공허의 지팡이", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:0, magicDefense:0,
		 spell:70, coolDown:0, speed:0, spellUp:0, speedUp:0, 
		 passiveEffect:"분해: 마법 관통력 +40%",
		 activeEffect:"없음"
	},
	{item:"광전사의 군화", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:0, attackSpeed:0.35, defense:0, magicDefense:0,
		 spell:0, coolDown:0, speed:45, spellUp:0, speedUp:0, 
		 passiveEffect:"없음",
		 activeEffect:"없음"
	},
	{item:"구원", hp:200, hpRecovery:0.5, hpRecovery5s:0, mp:0, mpRecovery:1.5,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:0, magicDefense:0,
		 spell:0, coolDown:0.1, speed:0, spellUp:0, speedUp:0, 
		 passiveEffect:"보호막 및 체력 회복 +10%",
		 activeEffect:"5500 거리 안의 위치를 지정합니다. 2.5초 후 빛을 한 줄기 불러와 아군의 체력을 10 (+ 대상 레벨당 20)만큼 회복시키고 적 챔피언에게 최대 체력의 10%에 해당하는 고정 피해를 입힙니다. 적 미니언에게는 250의 고정 피해를 입힙니다. (재사용 대기시간 120초) 구원의 체력 회복량은 보호막 및 체력 회복 효과를 3배로 적용받습니다.죽은 상태로도 사용할 수 있습니다."
	},
	{item:"기동력의 장화", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:0, magicDefense:0,
		 spell:0, coolDown:0, speed:25, spellUp:0, speedUp:0, 
		 passiveEffect:"이동속도 +25. 5초 동안 전투에서 벗어나 있으면 이동 속도가 +115로 상승합니다.",
		 activeEffect:"없음"
	},
	{item:"닌자의 신발", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:20, magicDefense:0,
		 spell:0, coolDown:0, speed:45, spellUp:0, speedUp:0, 
		 passiveEffect:"기본 공격 피해량의 12%를 막아줍니다.",
		 activeEffect:"없음"
	},
	{item:"라바돈의 죽음모자", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:0, magicDefense:0,
		 spell:120, coolDown:0, speed:0, spellUp:0.4, speedUp:0, 
		 passiveEffect:"주문력이 40% 증가합니다.",
		 activeEffect:"없음"
	},
	{item:"루덴의 메아리", hp:0, hpRecovery:0, hpRecovery5s:0, mp:600, mpRecovery:0,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:0, magicDefense:0,
		 spell:90, coolDown:0.1, speed:0, spellUp:0, speedUp:0, 
		 passiveEffect:"메아리: 이동하거나 주문을 시전할 때 전류가 충전됩니다. 충전량이 100이 되면, 다음 스킬 공격 시 충전된 전류를 전부 방출해, 최대 4명의 적에게 100 (+주문력의 10%)에 해당하는 추가 마법 피해를 가합니다.",
		 activeEffect:"없음"
	},
	{item:"마법공학 초기형 벨트", hp:300, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:0, magicDefense:0,
		 spell:60, coolDown:0.1, speed:0, spellUp:0, speedUp:0,
		 passiveEffect:"없음",
		 activeEffect:"화염 탄환: 앞으로 돌진해 75 ~ 150 (+0.25 주문력)의 마법 피해를 입히는 화염 탄환을 방사형으로 발사합니다. (재사용 대기시간은 40초이며 다른 마법공학 아이템과 재사용 대기시간을 공유합니다.) 챔피언이나 몬스터가 화염 탄환을 여러 발 맞을 경우 추가되는 탄환 하나당 10%의 피해를 입습니다. (돌진으로 지형은 통과할 수 없습니다.)"
	},
	{item:"마법공학 총검", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:40, attackSpeed:0, defense:0, magicDefense:0,
		 spell:80, coolDown:0, speed:0, spellUp:0, speedUp:0, 
		 passiveEffect:"적에게 가한 피해량의 15%만큼 회복합니다. 광역 피해는 33%만 적용됩니다.",
		 activeEffect:"번개: 175 ~ 250 (+0.3 주문력)의 마법 피해를 입히고, 대상 챔피언의 이동 속도가 2초 동안 40% 감소합니다. (재사용 대기시간은 40초이며 다른 마법공학 아이템과 재사용 대기시간을 공유합니다.)"
		},
	{item:"마법사의 신발", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:0, magicDefense:0,
		 spell:75, coolDown:0, speed:45, spellUp:0, speedUp:0, 
		 passiveEffect:"마법 관통력 +18",
		 activeEffect:"없음"
	},	
	{item:"망자의 갑옷", hp:425, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:60, magicDefense:0,
		 spell:0, coolDown:0, speed:0, spellUp:0, speedUp:0, 
		 passiveEffect:"없음",
		 activeEffect:"전함: 이동 시 추진력 중첩이 쌓여, 100 중첩이 되면 이동 속도가 최대 60까지 상승합니다. 추진력은 기절, 도발, 공포, 변이, 이동 불가 효과의 영향을 받으면 추진력이 줄어듭니다./ 강력한 일격: 기본 공격 시 중첩을 모두 방출하며 추진력 중첩 하나당 1의 마법 피해를 입힙니다. 공격자가 근접 챔피언인 경우 중첩이 최대치일 때 대상을 1초 동안 50% 둔화시킵니다."
	},
	{item:"모렐로노미콘", hp:300, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:0, magicDefense:0,
		 spell:70, coolDown:0, speed:0, spellUp:0, speedUp:0, 
		 passiveEffect:"죽음의 감촉: 마법 관통력 +15 / 저주받은 일격: 챔피언에게 마법 피해를 가하면 3초 동안 고통스러운 상처를 남깁니다. 고통스러운 상처는 치료 효과를 40% 감소시킵니다.",
		 activeEffect:"없음"
	},
	{item:"몰락한 왕의 검", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:40, attackSpeed:0.25, defense:0, magicDefense:0,
		 spell:0, coolDown:0, speed:0, spellUp:0, speedUp:0, 
		 passiveEffect:"기본 공격 적중 시 대상의 현재 체력의 8%에 해당하는 추가 물리 피해를 입힙니다. (최소 피해 15, 몬스터, 미니언 상대 시 최대 60)/ 생명력 흡수 +12%",
		 activeEffect:"범위 550 내의 적 챔피언에게 100의 마법 피해를 입힙니다. 또한, 대상 이동 속도의 25%를 3초 동안 훔칩니다. (재사용 대기시간 90초)"
	},
	{item:"무한의 대검", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:80, attackSpeed:0, defense:0, magicDefense:0,
		 spell:0, coolDown:0, speed:0, spellUp:0, speedUp:0, 
		 passiveEffect:"치명타가 피해량의 200%가 아닌 225%를 가합니다./ 치명타 확률 +25%",
		 activeEffect:"없음"
	},
	{item:"불타는 향로", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0.5,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:0, magicDefense:0,
		 spell:60, coolDown:0.1, speed:0, spellUp:0, speedUp:0.08, 
		 passiveEffect:"회복 및 방어막 효과 +10%/ 이동 속도 +8%/ 아군 챔피언을 치유하거나 보호막을 씌워주면 6초간 자신의 챔피언과 아군 챔피언의 레벨에 따라 대상의 공격 속도가 +10~30%, 적중시 5~20의 추가 마법 피해가 적용됩니다.",
		 activeEffect:"없음"
	},
	{item:"삼위일체", hp:250, hpRecovery:0, hpRecovery5s:0, mp:250, mpRecovery:0.5,
		 mpRecovery5s:0, attack:25, attackSpeed:0.4, defense:0, magicDefense:0,
		 spell:60, coolDown:0.2, speed:0, spellUp:0, speedUp:0.05, 
		 passiveEffect:"이동 속도 +5%/ 격분: 기본 공격 시 2초간 이동 속도가 20 상승합니다. 적을 처치하면 이동 속도가 60 상승합니다. 원거리 챔피언의 경우 이동 속도 상승 효과는 절반만 적용됩니다./ 주문 검: 스킬을 사용하고 나면 다음 기본 공격 적중 시 기본 공격력의 200%에 해당하는 추가 물리 피해를 입힙니다. (재사용 대기시간 1.5초)",
		 activeEffect:"없음"
	},
	{item:"수호 천사", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:45, attackSpeed:0, defense:40, magicDefense:0,
		 spell:0, coolDown:0, speed:0, spellUp:0, speedUp:0, 
		 passiveEffect:"치명적인 피해를 입으면 4초 동안 경직에 걸린 다음 기본 체력의 50%, 최대 마나의 30%를 회복합니다. (재사용 대기시간 5분)",
		 activeEffect:"없음"
	},
	{item:"스테락의 도전", hp:450, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:0, magicDefense:0,
		 spell:0, coolDown:0, speed:0, spellUp:0, speedUp:0, 
		 passiveEffect:"거인의 힘: 기본 공격력의 50%를 추가 공격력으로 얻습니다./ 생명선: 5초 안에 400 ~ 1800 이상의 피해를 (레벨에 비례) 입으면 추가 체력의 75%에 해당하는 보호막이 생깁니다. 0.75초 후 보호막은 3초에 걸쳐 서서히 사라집니다. (재사용 대기시간 60초)/ 스테락의 분노: 생명선 효과가 발동되면 8초 동안 몸집과 힘이 커지고, 강인함이 +30% 증가합니다.",
		 activeEffect:"없음"
	},
	{item:"아테나의 부정한 성배", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:1.0,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:0, magicDefense:30,
		 spell:30, coolDown:0.1, speed:0, spellUp:0, speedUp:0, 
		 passiveEffect:"챔피언에게 피해를 입혔을 때, 감소 전 피해량의 35%를 최대 100~250까지 피의 중첩으로 쌓습니다. 아군의 체력을 회복시키거나 보호막을 씌울 때 체력 회복량 또는 보호막 흡수량의 100%만큼 피의 중첩을 소모하여 아군을 회복시킵니다./ 부조화: 기본 마나 재생 25%마다 주문력이 5만큼 증가합니다. 다른 아이템에 있는 조화 효과를 비활성화합니다.",
		 activeEffect:"없음"
	},
	{item:"얼음정수파편", hp:100, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:1.0,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:0, magicDefense:30,
		 spell:25, coolDown:0.1, speed:0, spellUp:0, speedUp:0, 
		 passiveEffect:"10초당 골드 +3", 
		 activeEffect:"와드 설치: 투명 와드를 설치합니다. 상점 방문 시 4회의 충전량이 다시 채워집니다."
	},
	{item:"유령무희", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:0, attackSpeed:0.3, defense:0, magicDefense:0,
		 spell:0, coolDown:0, speed:0, spellUp:0, speedUp:0.05, 
		 passiveEffect:"치명타 확률 +25%/ 이동 속도 +5%/ 망령의 왈츠: 적 챔피언을 기본 공격하면 유령 상태가 되고 2초 동안 이동 속도가 7% 증가합니다./ 생명선: 피해를 받아 체력이 30% 이하가 될 경우, 2초 동안 최대 240~600의 피해를 흡수하는 보호막을 생성합니다. (재사용 대기시간 90초)",
		 activeEffect:"없음"
	},
	{item:"정령의 형상", hp:450, hpRecovery:1.0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:0, magicDefense:55,
		 spell:0, coolDown:0, speed:0, spellUp:0, speedUp:0, 
		 passiveEffect:"받는 모든 치유 효과가 30% 증가합니다.",
		 activeEffect:"없음"
	},
	{item:"정수약탈자", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:75, attackSpeed:0, defense:0, magicDefense:0,
		 spell:0, coolDown:0.2, speed:0, spellUp:0, speedUp:0, 
		 passiveEffect:"치명타 확률 +25%/ 기본 공격 시 잃은 마나의 1.5%를 회복합니다.",
		 activeEffect:"없음"
	},
	{item:"존야의 모래시계", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:45, magicDefense:0,
		 spell:75, coolDown:0.1, speed:0, spellUp:0, speedUp:0, 
		 passiveEffect:"없음",
		 activeEffect:"경직: 챔피언이 2.5초 동안 아무런 행동도 취할 수 없는 대신 공격도 받지 않는 무적 상태가 됩니다 (재사용 대기시간 120초)."
	},
	{item:"칠흑의 양날도끼", hp:400, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:40, attackSpeed:0, defense:0, magicDefense:0,
		 spell:0, coolDown:0.2, speed:0, spellUp:0, speedUp:0, 
		 passiveEffect:"물리 피해를 입힐 경우 대상의 방어력을 6초 동안 4%만큼 감소시킵니다. (최대 24%)/ 격분: 적에게 물리 피해를 적중시키면 2초간 이동 속도가 20 상승합니다. 미니언, 몬스터를 처치하거나 챔피언 킬 또는 어시스트를 올리면 2초간 이동 속도가 60 상승합니다. 원거리 챔피언일 경우 이동 속도 상승치는 절반이 됩니다.",
		 activeEffect:"없음"
	},
	{item:"헤르메스의 발걸음", hp:0, hpRecovery:0, hpRecovery5s:0, mp:0, mpRecovery:0,
		 mpRecovery5s:0, attack:0, attackSpeed:0, defense:0, magicDefense:25,
		 spell:0, coolDown:0, speed:45, spellUp:0, speedUp:0,
		 passiveEffect:"강인함: 기절, 둔화, 도발, 공포, 침묵, 실명 및 이동 불가 효과의 지속 시간이 30% 감소됩니다.",
		 activeEffect:"없음"
	}
]

function iSelecting() {
	let item1 = document.getElementsByName("item1")[0].value;
	let itemPic1 = document.getElementById("itemPic1");
	
	let ihp1 = document.getElementById('ihp1'),
		ihpRecovery1 = document.getElementById('ihpRecovery1'),
		ihpRecovery5s1 = document.getElementById('ihpRecovery5s1'),
		imp1 = document.getElementById('imp1'),
		impRecovery1 = document.getElementById('impRecovery1'),
		impRecovery5s1 = document.getElementById('impRecovery5s1'),
		iattack1 = document.getElementById('iattack1'),
		iattackSpeed1 = document.getElementById('iattackSpeed1'),
		idefense1 = document.getElementById('idefense1'),
		imagicDefense1 = document.getElementById('imagicDefense1'),
		ispell1 = document.getElementById('ispell1'),
		icoolDown1 = document.getElementById('icoolDown1'),
		ispeed1 = document.getElementById('ispeed1'),
		ispellUp1 = document.getElementById('ispellUp1'),
		ispeedUp1 = document.getElementById('ispeedUp1'),
		ipassiveEffect1 = document.getElementById('ipassiveEffect1'),
		iactiveEffect1 = document.getElementById('iactiveEffect1');
	
	for(let i=0; i<=items.length; i++){
		if(item1==items[i].item){
			itemPic1.innerHTML = '<img src="/lol/resources/img/item/'+item1+'.jpg">'
			ihp1.innerHTML = items[i].hp;
			ihpRecovery1.innerHTML = items[i].hpRecovery;
			ihpRecovery5s1.innerHTML = items[i].hpRecovery5s;
			imp1.innerHTML = items[i].mp;
			impRecovery1.innerHTML = items[i].mpRecovery;
			impRecovery5s1.innerHTML = items[i].mpRecovery5s;
			iattack1.innerHTML = items[i].attack;
			iattackSpeed1.innerHTML = items[i].attackSpeed;
			idefense1.innerHTML = items[i].defense;
			imagicDefense1.innerHTML = items[i].magicDefense;
			ispell1.innerHTML = items[i].spell;
			icoolDown1.innerHTML = items[i].coolDown;
			ispeed1.innerHTML = items[i].speed;
			ispellUp1.innerHTML = items[i].spellUp;
			ispeedUp1.innerHTML = items[i].speedUp;
			ipassiveEffect1.innerHTML = items[i].passiveEffect;
			iactiveEffect1.innerHTML = items[i].activeEffect;
		}
		
	}
	
}

function iSelecting2() {
	let item2 = document.getElementsByName("item2")[0].value;
	let itemPic2 = document.getElementById("itemPic2");
	
	let ihp2 = document.getElementById('ihp2'),
		ihpRecovery2 = document.getElementById('ihpRecovery2'),
		ihpRecovery5s2 = document.getElementById('ihpRecovery5s2'),
		imp2 = document.getElementById('imp2'),
		impRecovery2 = document.getElementById('impRecovery2'),
		impRecovery5s2 = document.getElementById('impRecovery5s2'),
		iattack2 = document.getElementById('iattack2'),
		iattackSpeed2 = document.getElementById('iattackSpeed2'),
		idefense2 = document.getElementById('idefense2'),
		imagicDefense2 = document.getElementById('imagicDefense2'),
		ispell2 = document.getElementById('ispell2'),
		icoolDown2 = document.getElementById('icoolDown2'),
		ispeed2 = document.getElementById('ispeed2'),
		ispellUp2 = document.getElementById('ispellUp2'),
		ispeedUp2 = document.getElementById('ispeedUp2'),
		ipassiveEffect2 = document.getElementById('ipassiveEffect2'),
		iactiveEffect2 = document.getElementById('iactiveEffect2');
	
	for(let i=0; i<=items.length; i++){
		if(item2==items[i].item){
			itemPic2.innerHTML = '<img src="/lol/resources/img/item/'+item2+'.jpg">'
			ihp2.innerHTML = items[i].hp;
			ihpRecovery2.innerHTML = items[i].hpRecovery;
			ihpRecovery5s2.innerHTML = items[i].hpRecovery5s;
			imp2.innerHTML = items[i].mp;
			impRecovery2.innerHTML = items[i].mpRecovery;
			impRecovery5s2.innerHTML = items[i].mpRecovery5s;
			iattack2.innerHTML = items[i].attack;
			iattackSpeed2.innerHTML = items[i].attackSpeed;
			idefense2.innerHTML = items[i].defense;
			imagicDefense2.innerHTML = items[i].magicDefense;
			ispell2.innerHTML = items[i].spell;
			icoolDown2.innerHTML = items[i].coolDown;
			ispeed2.innerHTML = items[i].speed;
			ispellUp2.innerHTML = items[i].spellUp;
			ispeedUp2.innerHTML = items[i].speedUp;
			ipassiveEffect2.innerHTML = items[i].passiveEffect;
			iactiveEffect2.innerHTML = items[i].activeEffect;
		}
		
	}
	
}

function iSelecting3() {
	let item3 = document.getElementsByName("item3")[0].value;
	let itemPic3 = document.getElementById("itemPic3");
	
	let ihp3 = document.getElementById('ihp3'),
		ihpRecovery3 = document.getElementById('ihpRecovery3'),
		ihpRecovery5s3 = document.getElementById('ihpRecovery5s3'),
		imp3 = document.getElementById('imp3'),
		impRecovery3 = document.getElementById('impRecovery3'),
		impRecovery5s3 = document.getElementById('impRecovery5s3'),
		iattack3 = document.getElementById('iattack3'),
		iattackSpeed3 = document.getElementById('iattackSpeed3'),
		idefense3 = document.getElementById('idefense3'),
		imagicDefense3 = document.getElementById('imagicDefense3'),
		ispell3 = document.getElementById('ispell3'),
		icoolDown3 = document.getElementById('icoolDown3'),
		ispeed3 = document.getElementById('ispeed3'),
		ispellUp3 = document.getElementById('ispellUp3'),
		ispeedUp3 = document.getElementById('ispeedUp3'),
		ipassiveEffect3 = document.getElementById('ipassiveEffect3'),
		iactiveEffect3 = document.getElementById('iactiveEffect3');
	
	for(let i=0; i<=items.length; i++){
		if(item3==items[i].item){
			itemPic3.innerHTML = '<img src="/lol/resources/img/item/'+item3+'.jpg">'
			ihp3.innerHTML = items[i].hp;
			ihpRecovery3.innerHTML = items[i].hpRecovery;
			ihpRecovery5s3.innerHTML = items[i].hpRecovery5s;
			imp3.innerHTML = items[i].mp;
			impRecovery3.innerHTML = items[i].mpRecovery;
			impRecovery5s3.innerHTML = items[i].mpRecovery5s;
			iattack3.innerHTML = items[i].attack;
			iattackSpeed3.innerHTML = items[i].attackSpeed;
			idefense3.innerHTML = items[i].defense;
			imagicDefense3.innerHTML = items[i].magicDefense;
			ispell3.innerHTML = items[i].spell;
			icoolDown3.innerHTML = items[i].coolDown;
			ispeed3.innerHTML = items[i].speed;
			ispellUp3.innerHTML = items[i].spellUp;
			ispeedUp3.innerHTML = items[i].speedUp;
			ipassiveEffect3.innerHTML = items[i].passiveEffect;
			iactiveEffect3.innerHTML = items[i].activeEffect;
		}
		
	}
	
}

function iSelecting4() {
	let item4 = document.getElementsByName("item4")[0].value;
	let itemPic4 = document.getElementById("itemPic4");
	
	let ihp4 = document.getElementById('ihp4'),
		ihpRecovery4 = document.getElementById('ihpRecovery4'),
		ihpRecovery5s4 = document.getElementById('ihpRecovery5s4'),
		imp4 = document.getElementById('imp4'),
		impRecovery4 = document.getElementById('impRecovery4'),
		impRecovery5s4 = document.getElementById('impRecovery5s4'),
		iattack4 = document.getElementById('iattack4'),
		iattackSpeed4 = document.getElementById('iattackSpeed4'),
		idefense4 = document.getElementById('idefense4'),
		imagicDefense4 = document.getElementById('imagicDefense4'),
		ispell4 = document.getElementById('ispell4'),
		icoolDown4 = document.getElementById('icoolDown4'),
		ispeed4 = document.getElementById('ispeed4'),
		ispellUp4 = document.getElementById('ispellUp4'),
		ispeedUp4 = document.getElementById('ispeedUp4'),
		ipassiveEffect4 = document.getElementById('ipassiveEffect4'),
		iactiveEffect4 = document.getElementById('iactiveEffect4');
	
	for(let i=0; i<=items.length; i++){
		if(item4==items[i].item){
			itemPic4.innerHTML = '<img src="/lol/resources/img/item/'+item4+'.jpg">'
			ihp4.innerHTML = items[i].hp;
			ihpRecovery4.innerHTML = items[i].hpRecovery;
			ihpRecovery5s4.innerHTML = items[i].hpRecovery5s;
			imp4.innerHTML = items[i].mp;
			impRecovery4.innerHTML = items[i].mpRecovery;
			impRecovery5s4.innerHTML = items[i].mpRecovery5s;
			iattack4.innerHTML = items[i].attack;
			iattackSpeed4.innerHTML = items[i].attackSpeed;
			idefense4.innerHTML = items[i].defense;
			imagicDefense4.innerHTML = items[i].magicDefense;
			ispell4.innerHTML = items[i].spell;
			icoolDown4.innerHTML = items[i].coolDown;
			ispeed4.innerHTML = items[i].speed;
			ispellUp4.innerHTML = items[i].spellUp;
			ispeedUp4.innerHTML = items[i].speedUp;
			ipassiveEffect4.innerHTML = items[i].passiveEffect;
			iactiveEffect4.innerHTML = items[i].activeEffect;
		}
		
	}
	
}

function iSelecting5() {
	let item5 = document.getElementsByName("item5")[0].value;
	let itemPic5 = document.getElementById("itemPic5");
	
	let ihp5 = document.getElementById('ihp5'),
		ihpRecovery5 = document.getElementById('ihpRecovery5'),
		ihpRecovery5s5 = document.getElementById('ihpRecovery5s5'),
		imp5 = document.getElementById('imp5'),
		impRecovery5 = document.getElementById('impRecovery5'),
		impRecovery5s5 = document.getElementById('impRecovery5s5'),
		iattack5 = document.getElementById('iattack5'),
		iattackSpeed5 = document.getElementById('iattackSpeed5'),
		idefense5 = document.getElementById('idefense5'),
		imagicDefense5 = document.getElementById('imagicDefense5'),
		ispell5 = document.getElementById('ispell5'),
		icoolDown5 = document.getElementById('icoolDown5'),
		ispeed5 = document.getElementById('ispeed5');
		ispellUp5 = document.getElementById('ispellUp5'),
		ispeedUp5 = document.getElementById('ispeedUp5'),
		ipassiveEffect5 = document.getElementById('ipassiveEffect5');
		iactiveEffect5 = document.getElementById('iactiveEffect5');
	
	for(let i=0; i<=items.length; i++){
		if(item5==items[i].item){
			itemPic5.innerHTML = '<img src="/lol/resources/img/item/'+item5+'.jpg">'
			ihp5.innerHTML = items[i].hp;
			ihpRecovery5.innerHTML = items[i].hpRecovery;
			ihpRecovery5s5.innerHTML = items[i].hpRecovery5s;
			imp5.innerHTML = items[i].mp;
			impRecovery5.innerHTML = items[i].mpRecovery;
			impRecovery5s5.innerHTML = items[i].mpRecovery5s;
			iattack5.innerHTML = items[i].attack;
			iattackSpeed5.innerHTML = items[i].attackSpeed;
			idefense5.innerHTML = items[i].defense;
			imagicDefense5.innerHTML = items[i].magicDefense;
			ispell5.innerHTML = items[i].spell;
			icoolDown5.innerHTML = items[i].coolDown;
			ispeed5.innerHTML = items[i].speed;
			ispellUp5.innerHTML = items[i].spellUp;
			ispeedUp5.innerHTML = items[i].speedUp;
			ipassiveEffect5.innerHTML = items[i].passiveEffect;
			iactiveEffect5.innerHTML = items[i].activeEffect;
		}
		
	}
	
}

function iSelecting6() {
	let item6 = document.getElementsByName("item6")[0].value;
	let itemPic6 = document.getElementById("itemPic6");
	
	let ihp6 = document.getElementById('ihp6'),
		ihpRecovery6 = document.getElementById('ihpRecovery6'),
		ihpRecovery5s6 = document.getElementById('ihpRecovery5s6'),
		imp6 = document.getElementById('imp6'),
		impRecovery6 = document.getElementById('impRecovery6'),
		impRecovery5s6 = document.getElementById('impRecovery5s6'),
		iattack6 = document.getElementById('iattack6'),
		iattackSpeed6 = document.getElementById('iattackSpeed6'),
		idefense6 = document.getElementById('idefense6'),
		imagicDefense6 = document.getElementById('imagicDefense6'),
		ispell6 = document.getElementById('ispell6'),
		icoolDown6 = document.getElementById('icoolDown6'),
		ispeed6 = document.getElementById('ispeed6');
		ispellUp6 = document.getElementById('ispellUp6'),
		ispeedUp6 = document.getElementById('ispeedUp6'),	
		ipassiveEffect6 = document.getElementById('ipassiveEffect6');
		iactiveEffect6 = document.getElementById('iactiveEffect6');
	
	for(let i=0; i<=items.length; i++){
		if(item6==items[i].item){
			itemPic6.innerHTML = '<img src="/lol/resources/img/item/'+item6+'.jpg">'
			ihp6.innerHTML = items[i].hp;
			ihpRecovery6.innerHTML = items[i].hpRecovery;
			ihpRecovery5s6.innerHTML = items[i].hpRecovery5s;
			imp6.innerHTML = items[i].mp;
			impRecovery6.innerHTML = items[i].mpRecovery;
			impRecovery5s6.innerHTML = items[i].mpRecovery5s;
			iattack6.innerHTML = items[i].attack;
			iattackSpeed6.innerHTML = items[i].attackSpeed;
			idefense6.innerHTML = items[i].defense;
			imagicDefense6.innerHTML = items[i].magicDefense;
			ispell6.innerHTML = items[i].spell;
			icoolDown6.innerHTML = items[i].coolDown;
			ispeed6.innerHTML = items[i].speed;
			ispellUp6.innerHTML = items[i].spellUp;
			ispeedUp6.innerHTML = items[i].speedUp;
			ipassiveEffect6.innerHTML = items[i].passiveEffect;
			iactiveEffect6.innerHTML = items[i].activeEffect;
		}
		
	}
	
}