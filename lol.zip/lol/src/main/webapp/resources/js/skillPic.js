let cName = document.getElementById("champName").childNodes[0].nodeValue;

let passiveName = document.getElementById("passiveName"),
	passivePic = document.getElementById("passivePic"),
	passiveDes = document.getElementById("passiveDes"),
	passivePic2 = document.getElementById("passivePic2"),
	passiveDes2 = document.getElementById("passiveDes2");

let pEffect1 = document.getElementById("pEffect1"),
	pEffect2 = document.getElementById("pEffect2"),
	pEffect3 = document.getElementById("pEffect3"),
	pEffect4 = document.getElementById("pEffect4");

let qName = document.getElementById("qName"),
	qPic = document.getElementById("qPic"),
	qDes = document.getElementById("qDes"),
	qPic2 = document.getElementById("qPic2"),
	qDes2 = document.getElementById("qDes2");

let qEffect1 = document.getElementById("qEffect1"),
	qEffect2 = document.getElementById("qEffect2"),
	qEffect3 = document.getElementById("qEffect3"),
	qEffect4 = document.getElementById("qEffect4");
	qEffect5 = document.getElementById("qEffect5");
	qEffect6 = document.getElementById("qEffect6");

let wName = document.getElementById("wName"),
	wPic = document.getElementById("wPic"),
	wDes = document.getElementById("wDes"),
	wPic2 = document.getElementById("wPic2"),
	wDes2 = document.getElementById("wDes2");
	
let wEffect1 = document.getElementById("wEffect1"),
	wEffect2 = document.getElementById("wEffect2"),
	wEffect3 = document.getElementById("wEffect3"),
	wEffect4 = document.getElementById("wEffect4");
	wEffect5 = document.getElementById("wEffect5");
	wEffect6 = document.getElementById("wEffect6");

let eName = document.getElementById("eName"),
	ePic = document.getElementById("ePic"),
	eDes = document.getElementById("eDes"),
	ePic2 = document.getElementById("ePic2"),
	eDes2 = document.getElementById("eDes2");
	
let eEffect1 = document.getElementById("eEffect1"),
	eEffect2 = document.getElementById("eEffect2"),
	eEffect3 = document.getElementById("eEffect3"),
	eEffect4 = document.getElementById("eEffect4");
	eEffect5 = document.getElementById("eEffect5");
	eEffect6 = document.getElementById("eEffect6");

let rName = document.getElementById("rName"),
	rPic = document.getElementById("rPic"),
	rDes = document.getElementById("rDes"),
	rPic2 = document.getElementById("rPic2"),
	rDes2 = document.getElementById("rDes2");
	
let rEffect1 = document.getElementById("rEffect1"),
	rEffect2 = document.getElementById("rEffect2"),
	rEffect3 = document.getElementById("rEffect3"),
	rEffect4 = document.getElementById("rEffect4");	
	rEffect5 = document.getElementById("rEffect5");	
	rEffect6 = document.getElementById("rEffect6");	
	
if(cName=="가렌") {
	passiveName.innerHTML='<h2>패시브 : 인내심</h2>'
    passivePic.innerHTML='<img src="/lol/resources/img/skill/GarenPassive.jpg">'
    passiveDes.innerHTML='가렌은 7초 동안 피해를 입거나 적의 스킬에 맞지 않으면 5초당 최대 체력의 일정 비율만큼 회복합니다. 미니언과 에픽 몬스터를 제외한 몬스터는 인내심에 영향을 주지 않습니다.'
    pEffect1.innerHTML='체력 회복 : 5초당 최대 체력의 1.5 ~ 10.8%'
    pEffect2.innerHTML='재사용 대기시간 : 7초'
    
    qName.innerHTML='<h2>Q스킬 : 결정타</h2>'
    qPic.innerHTML='<img src="/lol/resources/img/skill/GarenQ.jpg">'
    qDes.innerHTML='가렌에게 적용된 모든 둔화 효과가 풀리며 일정 시간 이동 속도가 30% 상승합니다. 4.5초 안에 하는 다음 기본 공격은 추가 물리 피해를 입히고 대상을 1.5초 동안 침묵시킵니다.'
   	qEffect1.innerHTML='데미지(물리) : 30 / 60 / 90 / 120 / 150 (+ 1.4 총 공격력)'
 	qEffect2.innerHTML='이동속도 증가 : 1.5 / 2.0 / 2.5 / 3.0 / 3.5 초'
 	qEffect3.innerHTML='재사용 대기시간 : 8초'
	 		
 	wName.innerHTML='<h2>W스킬 : 용기</h2>'	
 	wPic.innerHTML='<img src="/lol/resources/img/skill/GarenW.jpg">'	
 	wDes.innerHTML='기본 지속 효과: 유닛들을 처치하면 영구적으로 0.25의 방어력과 마법 저항력이 부여되어 최대 30까지 증가합니다.'
	wDes2.innerHTML='사용 시: 가렌이 일정 시간 동안 용기백배하여 받는 피해가 30% 감소합니다. 첫 0.75초 동안은 최대 체력의 10%에 해당하는 피해를 흡수하는 보호막과 60%의 강인함을 얻습니다.'
 	wEffect1.innerHTML='물리/마법 피해 30%감소 : 2 / 2.75 / 3.5 / 4.25 / 5초'	
 	wEffect2.innerHTML='재사용 대기시간 : 24 / 23 / 22 / 21 / 20초'	
	 		
 	eName.innerHTML='<h2>E스킬 : 심판</h2>'
 	ePic.innerHTML='<img src="/lol/resources/img/skill/GarenE.jpg">'
 	eDes2.innerHTML='가렌이 3초 동안 검을 들고 빠르게 회전하여 지속 시간 동안 근처 적에게 물리 피해를 입힙니다. 가장 가까운 적에게는 피해량이 25% 증가합니다. (공격 횟수는 아이템과 레벨의 공격 속도에 비례합니다.)회전에 6번 맞은 적 챔피언은 6초 동안 방어력이 25% 감소합니다. (6번 이후의 추가 공격은 적중시마다 효과 지속 시간을 초기화합니다.)'
	eEffect1.innerHTML='데미지(물리) : 4 / 8 / 12 / 16 / 20 (+레벨에 따라 0 ~ 8.2) (+ 0.32 / 0.34 / 0.36 / 0.38 / 0.40 총 공격력) × (기본 7회 + 아이템 및 레벨 업으로 얻는 공격 속도 25%마다 1회)/ 스킬을 빨리 취소하면 남은 스킬 지속시간만큼 재사용 대기시간이 감소합니다.'	
 	eEffect2.innerHTML='사거리 : 325'
	eEffect3.innerHTML='재사용 대기시간 : 9초'
			
	rName.innerHTML='<h2>궁극기 : 데마시아의 정의</h2>'
	rPic.innerHTML='<img src="/lol/resources/img/skill/GarenR.jpg">'
 	rDes.innerHTML='가렌이 적 챔피언을 처단할 데마시아의 힘을 소환하여 고정 피해를 입히고 대상이 잃은 체력에 비례한 피해를 추가로 입힙니다. 아이템은 데미지에 영향을 주지 못합니다.사용한 대상을 1초 동안 볼 수 있으며, 대상이 시야에서 사라져도 스킬이 취소되지 않습니다.'
 	rEffect1.innerHTML='데미지(고정 피해량) : 150 / 300 / 450 (+ 잃은 체력의 20% / 25% / 30%)'	
 	rEffect2.innerHTML='사거리 : 400'
 	rEffect3.innerHTML='재사용 대기시간 : 120 / 100 / 80초'
}
else if(cName=="갈리오") {
	passiveName.innerHTML='<h2>패시브 : 석상의 강타</h2>'
    passivePic.innerHTML='<img src="/lol/resources/img/skill/GalioPassive.jpg">'
    passiveDes.innerHTML='갈리오의 다음 기본 공격이 근처 모든 적에게 마법 피해를 입힙니다.'
    pEffect1.innerHTML='데미지(마법) : (레벨에 따라)15 ~ 200 (+1.0 총 공격력) (+0.5 주문력) (+0.6 추가 마법 저항력)'
    pEffect2.innerHTML='재사용 대기시간 : 5초'
    
    qName.innerHTML='<h2>Q스킬 : 전장의 돌풍</h2>'
    qPic.innerHTML='<img src="/lol/resources/img/skill/GalioQ.jpg">'
    qDes.innerHTML='갈리오가 두 개의 돌풍을 발사해 마법 피해를 입힙니다. 두 돌풍이 합쳐지면 거대한 소용돌이가 일어나 1.5초 동안 적 최대 체력에 비례한 마법 피해를 입힙니다.'
   	qEffect1.innerHTML='데미지(마법) : 80 / 115 / 150 / 185 / 220 (+0.75 주문력) - 돌풍 피해 | 0.5초당 대상 최대 체력의 2(+0.0066 주문력)% - 소용돌이 피해 | 80 / 115 / 150 / 185 / 220 (+0.75 주문력) + 대상 최대 체력의 6(+0.02 주문력)% - 총 피해'
 	qEffect2.innerHTML='몬스터 대상 소용돌이 최대 피해량: 150'
 	qEffect3.innerHTML='돌풍 속도: 1300 | 소용돌이 범위: 235'
	qEffect4.innerHTML='마나 소모 : 70 / 75 / 80 / 85 / 90'
	qEffect5.innerHTML='사거리 : 825'
	qEffect6.innerHTML='재사용 대기시간 : 12 / 11.5 / 11 / 10.5 / 10초'
	 		
 	wName.innerHTML='<h2>W스킬 : 듀란드의 방패</h2>'	
 	wPic.innerHTML='<img src="/lol/resources/img/skill/GalioW.jpg">'	
 	wDes.innerHTML='기본 지속 효과: 12초 동안 피해를 입지 않으면 마법 피해를 흡수하는 보호막을 얻습니다.'
	wDes2.innerHTML='최초 시전 시: 갈리오가 방어 태세를 갖추며 최대 2초 동안 마법 피해량 감소 효과를 얻습니다. 해당 효과의 50%만큼 물리 피해량도 감소합니다. 방어 태세 중에는 15% 느려집니다. | 두 번째 시전 시: 갈리오가 주변의 적 챔피언들을 도발하고 마법 피해를 입히며, 피해량 감소 효과가 2초 재적용됩니다. 도발 범위 및 지속 시간과 피해량은 방어 태세를 유지한 시간에 비례합니다.'
 	wEffect1.innerHTML='보호막 : 최대 체력의 8 / 11 / 14 / 17 / 20% (피해를 입은 후 12초 이후에는 상시 지속)'	
 	wEffect2.innerHTML='사용시 방어력 증가 : 10 / 12.5 / 15 / 17.5 / 20% (+0.04 추가 마법 저항력) (+0.025 주문력) | 사용시 마법저항력 증가 : 20 / 25 / 30 / 35 / 40%(+0.08 추가 마법 저항력) (+0.05 주문력)'	
 	wEffect3.innerHTML='데미지(마법) : 20 / 35 / 50 / 65 / 80 (+0.3 주문력) - 최소 피해 | 60 / 105 / 150 / 195 / 240 (+0.9 주문력) - 최대 피해'	
 	wEffect4.innerHTML='마나 소모 : 50 | 도발 시간 : 0.5 ~ 1.5 초'	
 	wEffect5.innerHTML='사거리 : 275'	
 	wEffect6.innerHTML='재사용 대기시간 : 16 / 15 / 14 / 13 / 12초'	
	 		
 	eName.innerHTML='<h2>E스킬 : 심판</h2>'
 	ePic.innerHTML='<img src="/lol/resources/img/skill/GalioE.jpg">'
 	eDes2.innerHTML='갈리오가 전방으로 돌진해 첫 번째 적 챔피언에게 마법 피해를 입히고 0.75초 동안 공중으로 띄웁니다. 돌진 경로에 있는 적은 모두 절반에 해당하는 마법 피해를 입습니다. 정의의 주먹 사용 시 지형에 부딪치면 그 자리에 멈춥니다.'
	eEffect1.innerHTML='데미지(마법) : 90 / 130 / 170 / 210 / 250 (+0.9 주문력)'
 	eEffect3.innerHTML='마나 소모 : 50'
 	eEffect3.innerHTML='사거리 : 650'
	eEffect4.innerHTML='재사용 대기시간 : 14 / 13 / 12 / 11 / 10초'
	eEffect5.innerHTML='CC효과 : 에어본 - 0.75초'
			
	rName.innerHTML='<h2>궁극기 : 영웅출현</h2>'
	rPic.innerHTML='<img src="/lol/resources/img/skill/GalioR.jpg">'
 	rDes.innerHTML='갈리오가 아군 챔피언의 현재 위치를 착지 지점으로 정합니다. 착지 시 해당 지역에 있던 적은 모두 마법 피해를 입고 0.75초 동안 공중에 떠오릅니다.'
 	rEffect1.innerHTML='데미지(마법) : 150 / 250 / 350 (+0.6 주문력)'	
 	rEffect2.innerHTML='마나 소모 : 100'
	rEffect3.innerHTML='사거리 : 4000 / 4750 / 5500'
 	rEffect4.innerHTML='재사용 대기시간 : 200 / 180 / 160초'
 	rEffect5.innerHTML='CC효과 : 에어본 - 0.75초'
}
else if(cName=="루시안") {
	passiveName.innerHTML='<h2>패시브 : 빛의 사수</h2>'
    passivePic.innerHTML='<img src="/lol/resources/img/skill/LucianPassive.jpg">'
    passiveDes.innerHTML='루시안은 스킬을 사용한 후 기본 공격을 하면 총을 두 번 연속 발사합니다. 두 번째 공격은 적 챔피언과 구조물에 대해서는 공격력의 일정 비율의 피해를 입히고 적중 시 효과를 적용합니다. 미니언은 두 번째 공격에서 100%의 피해를 입습니다.'
    pEffect1.innerHTML='데미지(물리) : 0.5 / 0.55 / 0.6 총 공격력'
    pEffect2.innerHTML='치명타 시 데미지(물리) : 0.875 / 0.9625 / 1.05 총 공격력'
    
    qName.innerHTML='<h2>Q스킬 : 꿰뚫는 빛</h2>'
    qPic.innerHTML='<img src="/lol/resources/img/skill/LucianQ.jpg">'
    qDes.innerHTML='적 유닛 하나를 관통하는 빛 줄기를 발사하여, 일직선 상의 적들에게 물리 피해를 입힙니다.'
   	qEffect1.innerHTML='데미지(물리) : 85 / 120 / 155 / 190 / 225 (+0.6 / 0.75 / 0.9 / 1.05 / 1.2 추가 공격력)'
 	qEffect2.innerHTML='마나소모 : 50 / 60 / 70 / 80 / 90'
 	qEffect3.innerHTML='사거리 : 500'
	qEffect4.innerHTML='재사용 대기시간 : 9 / 8 / 7 / 6 / 5초'
	 		
 	wName.innerHTML='<h2>W스킬 : 타는 불빛</h2>'	
 	wPic.innerHTML='<img src="/lol/resources/img/skill/LucianW.jpg">'	
 	wDes.innerHTML='적을 맞히거나 경로 끝에 도달하면 폭발하는 탄환을 발사합니다. 폭발에 맞은 적에게 마법 피해를 입히고 6초 동안 표식을 남깁니다. 루시안이나 아군이 표식이 남은 적을 공격하면 루시안의 이동 속도가 1초간 상승합니다.'
 	wEffect1.innerHTML='데미지(마법) : 75 / 110 / 145 / 180 / 215 (+0.9 주문력)'		
 	wEffect2.innerHTML='이동속도 증가 : 60 / 65 / 70 / 75 / 80'	
 	wEffect3.innerHTML='마나 소모 : 70'	
 	wEffect4.innerHTML='사거리 : 900'	
 	wEffect5.innerHTML='재사용 대기시간 : 14 / 13 / 12 / 11 / 10초'	
	 		
 	eName.innerHTML='<h2>E스킬 : 끈질긴 추격</h2>'
 	ePic.innerHTML='<img src="/lol/resources/img/skill/LucianE.jpg">'
 	eDes2.innerHTML='짧은 거리를 빠르게 돌진합니다. 빛의 사수로 적을 맞힐 때마다 끈질긴 추격의 재사용 대기시간이 1초씩 감소합니다. (적 챔피언의 경우 두 배인 2초 감소)'
	eEffect1.innerHTML='데미지(마법) : 90 / 130 / 170 / 210 / 250 (+0.9 주문력)'
 	eEffect3.innerHTML='마나 소모 : 40 / 30 / 20 / 10 / 0'
 	eEffect3.innerHTML='이동거리 : 425'
	eEffect4.innerHTML='재사용 대기시간 : 22 / 20 / 18 / 16 / 14'
			
	rName.innerHTML='<h2>궁극기 : 빛의 심판</h2>'
	rPic.innerHTML='<img src="/lol/resources/img/skill/LucianR.jpg">'
 	rDes.innerHTML='루시안이 한 방향으로 3초 동안 빠르게 총을 난사하며 자유롭게 이동합니다. 이 총알들은 처음 맞는 적에게 충돌하며, 각각 물리 피해를 입힙니다. 총 20/25/30발 사격. 루시안은 빛의 심판을 사용하는 동안 끈질긴 추격을 사용할 수 있습니다. 빛의 심판을 한 번 더 사용하면 사격을 중지합니다.'
 	rEffect1.innerHTML='탄환 당 데미지(물리) : 20 / 40 / 60 (+0.25 공격력) (+0.1 주문력)'	
 	rEffect2.innerHTML='최대 피해량(물리) : 400 / 1000 / 1800 (+5 / 6.25 / 7.5 공격력) (+2 / 2.5 / 3 주문력)'
	rEffect3.innerHTML='마나 소모 : 100'
 	rEffect4.innerHTML='사거리 : 1200'
 	rEffect5.innerHTML='재사용 대기시간  : 110 / 100 / 90초'
}
else if(cName=="잔나") {
	passiveName.innerHTML='<h2>패시브 : 순풍</h2>'
    passivePic.innerHTML='<img src="/lol/resources/img/skill/JannaPassive.jpg">'
    passiveDes.innerHTML='범위 안의 모든 아군이 잔나를 향해 움직이고 있을 때 이동 속도 8%가 증가합니다. 잔나의 기본 공격 및 단일 대상 스킬이 추가 이동 속도의 25 / 35%에 해당하는 추가 마법 피해를 입힙니다.'
    pEffect1.innerHTML='유효 사거리 : 1250'
    pEffect2.innerHTML='이동속도 증가 : 8%'
   	pEffect3.innerHTML='이동속도에 따른 추가 마법피해 : 25 / 35%'
    
    qName.innerHTML='<h2>Q스킬 : 울부짖는 돌풍</h2>'
    qPic.innerHTML='<img src="/lol/resources/img/skill/JannaQ.jpg">'
    qDes.innerHTML='회오리바람을 소환하여 바람이 지나는 길목에 있는 모든 적에게 마법 피해를 입히고 0.5초 동안 공중으로 띄워 올립니다. 돌풍은 최대 3초까지 충전할 수 있습니다. 돌풍은 충전 시간 1초마다 추가 피해를 입히고, 적을 띄워올리는 시간이 0.25초 늘어나며, 이동 거리가 35% 증가합니다. 해당 스킬을 재시전하면 회오리 바람이 더 일찍 발사됩니다. 완전히 충전 후 사용 시 즉시 사용할 때보다 돌풍이 75% 빠르게 이동합니다.'
   	qEffect1.innerHTML='60 / 85 / 110 / 135 / 160 (+0.35 주문력) - 기본 마법 피해 | 15 / 20 / 25 / 30 / 35 (+0.1 주문력) - 추가 마법 피해 | 105 / 145 / 185 / 225 / 265 (+0.65 주문력) - 최대 마법 피해'
 	qEffect2.innerHTML='마나소모 : 60 / 80 / 100 / 120 / 140'
 	qEffect3.innerHTML='사거리 : 최소-850 / 완전 충전 시-1700 '
	qEffect4.innerHTML='재사용 대기시간 : 14 / 13 / 12 / 11 / 10초'
	qEffect5.innerHTML='CC효과 : 에어본 -0.5(최소)~1.5(완전 충전 시)초'
	 		
 	wName.innerHTML='<h2>W스킬 : 서풍</h2>'	
 	wPic.innerHTML='<img src="/lol/resources/img/skill/JannaW.jpg">'	
 	wDes.innerHTML='기본 지속 효과: 서풍이 재사용 대기 중이 아닐 때 잔나의 이동 속도가 증가하고 유닛을 통과해 움직일 수 있습니다. | 사용 시: 적에게 마법 피해를 입히고, 2초 동안 적의 이동 속도를 늦춥니다.'
 	wEffect1.innerHTML='데미지(마법) : 55 / 90 / 125 / 160 / 195 (+0.5 주문력)'		
 	wEffect2.innerHTML='이동속도 증가 : 6 / 7 / 8 / 9 / 10% (+0.02 주문력%)'	
 	wEffect3.innerHTML='마나 소모 : 50 / 60 / 70 / 80 / 90'	
 	wEffect4.innerHTML='사거리 : 600'	
 	wEffect5.innerHTML='재사용 대기시간 : 14 / 13 / 12 / 11 / 10초'	
	wEffect5.innerHTML='CC효과 : 둔화-24 / 28 / 32 / 36 / 40% (+0.06 주문력%)/2초'	
	 		
 	eName.innerHTML='<h2>E스킬 : 폭풍의 눈</h2>'
 	ePic.innerHTML='<img src="/lol/resources/img/skill/JannaE.jpg">'
 	eDes2.innerHTML='아군 챔피언이나 포탑에 5초에 걸쳐 서서히 사라지는 보호막을 부여합니다. 보호막은 피해를 흡수하고, 완전히 사라지기 전까지 공격력을 부여합니다. 적 챔피언을 둔화시키거나 공중에 띄우면 남은 폭풍의 눈 재사용 대기시간이 20% 감소합니다.'
	eEffect1.innerHTML='보호막 : 80 / 115 / 150 / 185 / 220 (+0.7 주문력)'
 	eEffect2.innerHTML='공격력 증가 : 10 / 17.5 / 25 / 32.5 / 40 (+0.1 주문력)'
	eEffect3.innerHTML='마나 소모 : 70 / 80 / 90 / 100 / 110'
 	eEffect4.innerHTML='사거리 : 800'
	eEffect5.innerHTML='재사용 대기시간 : 16 / 15 / 14 / 13 / 12초'
			
	rName.innerHTML='<h2>궁극기 : 계절풍</h2>'
	rPic.innerHTML='<img src="/lol/resources/img/skill/JannaR.jpg">'
 	rDes.innerHTML='주위 적을 밀쳐내며 치유 효과가 있는 강력한 바람을 일으켜 3초에 걸쳐 주변 아군의 체력을 회복시킵니다.'
 	rEffect1.innerHTML='초당 회복량 : 100 / 150 / 200 (+0.5 주문력)'	
	rEffect2.innerHTML='마나 소모 : 100'
 	rEffect3.innerHTML='유효 사거리 : 725'	
 	rEffect4.innerHTML='재사용 대기시간  : 150 / 135 / 120초'
	rEffect5.innerHTML='CC효과 : 넉백'
}
else if(cName=="아칼리") {
	passiveName.innerHTML='<h2>패시브 : 암살자의 표식</h2>'
    passivePic.innerHTML='<img src="/lol/resources/img/skill/AkaliPassive.jpg">'
    passiveDes.innerHTML='스킬 공격으로 챔피언에게 피해를 입히면 해당 챔피언의 주변에 원이 생깁니다. 아칼리가 이 원의 경계를 넘어가면 카마의 사거리와 피해량이 증가합니다. 다음 공격의 사거리가 두 배로 증가하며 추가 마법 피해를 입히고 기력을 회복합니다. 원이 형성되면 아칼리가 원의 경계를 향해 이동할 때 이동 속도가 증가합니다. 아칼리가 원의 경계를 넘어가면 적을 향해 이동할 때 이동 속도가 증가합니다. 레벨이 오를때마다 3의 기본데미지가 추가됩니다.'
    pEffect1.innerHTML='데미지(마법): 39 ~ 180*(+0.6 추가 공격력)(+0.5 주문력)'	
    pEffect2.innerHTML='기력 회복 : 10 / 15 / 20 (1, 8, 13 레벨 때  변화)'
    pEffect3.innerHTML='추가 이동속도 : 40 / 50 / 60 / 70% (1/6/11/16 레벨 때 변화)'
    
    qName.innerHTML='<h2>Q스킬 : 오연투척검</h2>'
    qPic.innerHTML='<img src="/lol/resources/img/skill/AkaliQ.jpg">'
    qDes.innerHTML='단검을 부채꼴 모양으로 던져 마법 피해를 입힙니다. 사거리 끝에 있는 적들은 0.5초 동안 50%만큼 둔화됩니다. 최고 스킬 레벨에서 미니언과 몬스터에게 125%의 피해를 입힙니다.'
   	qEffect1.innerHTML='데미지(마법) : 25 / 50 / 75 / 100 / 125 (+0.65 총 공격력) (+0.6 주문력)'
 	qEffect2.innerHTML='기력 소모 : 100/95/90/85/80'
 	qEffect3.innerHTML='사거리 : 500'
 	qEffect4.innerHTML='재사용 대기시간 : 1.5초'
	qEffect5.innerHTML='CC효과 : 둔화-50%/0.5초'
 		
 	wName.innerHTML='<h2>W스킬 : 황혼의 장막</h2>'	
 	wPic.innerHTML='<img src="/lol/resources/img/skill/AkaliW.jpg">'	
 	wDes.innerHTML='연막탄을 떨어뜨려 연막을 생성합니다. 연막 안에 있는 동안 아칼리는 투명 상태가 되고 이동 속도가 증가합니다. 황혼의 장막은 일정 시간 동안 지속됩니다.'
 	wEffect1.innerHTML='은신 - 투명 근처의 적 포탑 또는 절대 시야만이 아칼리의 모습을 드러낼 수 있습니다.'	
 	wEffect2.innerHTML='기력 회복 : 80'	
 	wEffect3.innerHTML='이동속도 증가 : 20 / 25 / 30 / 35 / 40%'	
 	wEffect4.innerHTML='재사용 대기시간 : 20초 (연막의 지속시간이 종료된 이후에 재사용 대기시간에 돌입합니다.)'	
 		
 	eName.innerHTML='<h2>E스킬 : 표창곡예</h2>'
 	ePic.innerHTML='<img src="/lol/resources/img/skill/AkaliE1.jpg">'
 	eDes.innerHTML='뒤로 공중제비를 돌며 전방으로 표창을 던져 물리 피해를 입히고 표창에 맞은 첫 번째 적이나 연막에 표식을 남깁니다.'
 	ePic2.innerHTML='<img src="/lol/resources/img/skill/AkaliE2.jpg">'
 	eDes2.innerHTML='재사용 시: 표식을 남긴 대상에게 돌진해 물리 피해를 줍니다.'
	eEffect1.innerHTML='첫사용시 데미지(물리) : 40 / 70 / 100 / 130 / 160 (+0.35 총 공격력) (+0.5 주문력)'	
 	eEffect2.innerHTML='재사용시 데미지(물리) : 40 / 70 / 100 / 130 / 160 (+0.35 총 공격력) (+0.5 주문력)'
 	eEffect3.innerHTML='기력소모 : 30 '
	eEffect4.innerHTML='사거리 : 650(재사용시 전 지역)'
	eEffect5.innerHTML='재사용 대기시간 : 16 / 14.5 / 13 / 11.5 / 10초'
		
	rName.innerHTML='<h2>궁극기 : 무결처형</h2>'
	rPic.innerHTML='<img src="/lol/resources/img/skill/AkaliR1.jpg">'
 	rDes.innerHTML='첫 번째 돌진은 적들을 뛰어넘어 물리 피해를 입힙니다.'
 	rPic2.innerHTML='<img src="/lol/resources/img/skill/AkaliR2.jpg">'
 	rDes2.innerHTML='두 번째 돌진은 2.5초 후 사용이 가능하며 적들을 관통하여 대상이 잃은 체력에 비례한 마법 피해를 입힙니다.'
 	rEffect1.innerHTML='첫사용시  데미지(물리) : 85 / 150 / 215 (+0.5 추가 공격력)'	
 	rEffect2.innerHTML='첫사용시 사거리 : 600'
 	rEffect3.innerHTML='재사용시 최소 데미지(마법) : 85 / 150 / 215 (+0.3 주문력)'
 	rEffect4.innerHTML='재사용시 최대 데미지(마법) : 255 / 450 / 645 (+0.9 주문력)'
 	rEffect5.innerHTML='재사용시 사거리 : 600'
 	rEffect6.innerHTML='재사용 대기시간 : 160 / 130 / 100초'
		
}
