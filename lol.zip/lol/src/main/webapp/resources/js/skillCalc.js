function passiveCalc(){
	let chName = document.getElementById("champName").childNodes[0].nodeValue;
	let chLevel = Number(document.getElementsByClassName('champLevel')[0].value);
	
	let hp3 = Number(document.getElementById('hp3').childNodes[0].nodeValue),
	    hpRecovery3 = Number(document.getElementById('hpRecovery3').childNodes[0].nodeValue),
	   	resources3 = Number(document.getElementById('resources3').childNodes[0].nodeValue),
	   	resourcesRecovery3 = Number(document.getElementById('resourcesRecovery3').childNodes[0].nodeValue),
	   	attack3 = Number(document.getElementById('attack3').childNodes[0].nodeValue),
	   	attackSpeed3 = Number(document.getElementById('attackSpeed3').childNodes[0].nodeValue),
	   	defense3 = Number(document.getElementById('defense3').childNodes[0].nodeValue),
	   	magicDefense3 = Number(document.getElementById('magicDefense3').childNodes[0].nodeValue),
	   	range3 = Number(document.getElementById('range3').childNodes[0].nodeValue),
	   	speed3 = Number(document.getElementById('speed3').childNodes[0].nodeValue),
	   	spell3 = Number(document.getElementById('spell3').childNodes[0].nodeValue);
		coolDown3 = Number(document.getElementById('coolDown3').childNodes[0].nodeValue);
	
	let passiveCalc1 = document.getElementById('passiveCalc1'),
		passiveCalc2 = document.getElementById('passiveCalc2'),
		passiveCalc3 = document.getElementById('passiveCalc3'),
		passiveCalc4 = document.getElementById('passiveCalc4');
	
	if(chName=="가렌") {
		passiveCalc1.innerHTML ='체력 회복량 : 5초당 '+(hp3*(0.015+(0.0055*(chLevel-1)))).toFixed(1)+' 추가 회복'
	}
	
	if(chName=="갈리오") {
		passiveCalc1.innerHTML ='데미지 : '+(15+(10.9*(chLevel-1))+(1*attack3)+(0.5*spell)+(0.6*magicDefense3)).toFixed(1)
	}
	
	if(chName=="루시안") {
		if(chLevel<7) {
			passiveCalc1.innerHTML ='데미지 : '+(attack3*0.5).toFixed(1);
			passiveCalc2.innerHTML = '치명타 데미지 : '+((attack3*2)*0.875).toFixed(1);
		} else if(chLevel<13) {
			passiveCalc1.innerHTML ='데미지 : '+(attack3*0.55).toFixed(1);
			passiveCalc2.innerHTML = '치명타 데미지 : '+((attack3*2)*0.9625).toFixed(1);
		} else if(chLevel<19) {
			passiveCalc1.innerHTML ='데미지 : '+(attack3*0.6).toFixed(1);
			passiveCalc2.innerHTML = '치명타 데미지 : '+((attack3*2)*1.05).toFixed(1);
		}
		
	}
	
	if(chName=="아칼리") {
		passiveCalc1.innerHTML ='데미지 : '+((39+(3*(chLevel-1)))+(0.6*attack3)+(0.5*spell3)).toFixed(3)+' | ';
		if(chLevel<8) {
			passiveCalc2.innerHTML = '기력 회복 : '+10;
		} else if(chLevel<13) {
		passiveCalc2.innerHTML = '기력 회복 : '+15;
		} else if(chLevel<19) {
			passiveCalc2.innerHTML = '기력 회복 : '+20;
		}
		if(chLevel<6) {
			passiveCalc3.innerHTML = '이동속도 : '+(speed3*1.4).toFixed(1);
		} else if(chLevel<11) {
			passiveCalc3.innerHTML = '이동속도 : '+(speed3*1.5).toFixed(1);
		} else if(chLevel<16) {
			passiveCalc3.innerHTML = '이동속도 : '+(speed3*1.6).toFixed(1);
		} else if(chLevel<19) {
			passiveCalc3.innerHTML = '이동속도 : '+(speed3*1.7).toFixed(1);
		}
		passiveCalc4.innerHTML = '사거리 : '+ range3*2;
	}
	
	if(chName=="잔나") {
		passiveCalc1.innerHTML ='발동 시 이동속도 : '+(speed3*1.08).toFixed(1);
		if(chLevel<10){
			passiveCalc2.innerHTML = '추가 마법피해 데미지 : '+(speed3*0.25).toFixed(1);
		} 
		else if(chlevel<19) {
			passiveCalc2.innerHTML = '추가 마법피해 데미지 : '+(speed3*0.35).toFixed(1);
		}
	}
	
}

function qCalc() {
	let chName = document.getElementById("champName").childNodes[0].nodeValue;
	let chLevel = Number(document.getElementsByClassName('champLevel')[0].value);
	let qLevel = Number(document.getElementsByClassName('qLevel')[0].value);
	
	let qCalc1 = document.getElementById('qCalc1'),
		qCalc2 = document.getElementById('qCalc2'),
		qCalc3 = document.getElementById('qCalc3'),
		qCalc4 = document.getElementById('qCalc4'),
		qCalc5 = document.getElementById('qCalc5'),
		qCalc6 = document.getElementById('qCalc6');

	let hp3 = Number(document.getElementById('hp3').childNodes[0].nodeValue),
	    hpRecovery3 = Number(document.getElementById('hpRecovery3').childNodes[0].nodeValue),
	   	resources3 = Number(document.getElementById('resources3').childNodes[0].nodeValue),
	   	resourcesRecovery3 = Number(document.getElementById('resourcesRecovery3').childNodes[0].nodeValue),
	   	attack3 = Number(document.getElementById('attack3').childNodes[0].nodeValue),
	   	attackSpeed3 = Number(document.getElementById('attackSpeed3').childNodes[0].nodeValue),
	   	defense3 = Number(document.getElementById('defense3').childNodes[0].nodeValue),
	   	magicDefense3 = Number(document.getElementById('magicDefense3').childNodes[0].nodeValue),
	   	range3 = Number(document.getElementById('range3').childNodes[0].nodeValue),
	   	speed3 = Number(document.getElementById('speed3').childNodes[0].nodeValue),
	   	spell3 = Number(document.getElementById('spell3').childNodes[0].nodeValue);
		coolDown3 = Number(document.getElementById('coolDown3').childNodes[0].nodeValue);
	if(chName=="가렌") {
		if(qLevel==1){
			qCalc1.innerHTML = '데미지 : '+(30+(1.4*attack3));
			qCalc2.innerHTML = '이동속도 30% 증가 : '+speed3*1.3;
			qCalc3.innerHTML = '이동속도 증가 시간 : '+1.5+'초';
			qCalc4.innerHTML = '재사용 대기시간 : '+(8*(1-coolDown3)).toFixed(1)+'초';
		}
		if(qLevel==2){
			qCalc1.innerHTML = '데미지 : '+(60+(1.4*attack3));
			qCalc2.innerHTML = '이동속도 30% 증가 : '+speed3*1.3;
			qCalc3.innerHTML = '이동속도 증가 시간 : '+2+'초';
			qCalc4.innerHTML = '재사용 대기시간 : '+(8*(1-coolDown3)).toFixed(1)+'초';
		}
		if(qLevel==3){
			qCalc1.innerHTML = '데미지 : '+(90+(1.4*attack3));
			qCalc2.innerHTML = '이동속도 30% 증가 : '+speed3*1.3;
			qCalc3.innerHTML = '이동속도 증가 시간 : '+2.5+'초';
			qCalc4.innerHTML = '재사용 대기시간 : '+(8*(1-coolDown3)).toFixed(1)+'초';
		}
		if(qLevel==4){
			qCalc1.innerHTML = '데미지 : '+(120+(1.4*attack3));
			qCalc2.innerHTML = '이동속도 30% 증가 : '+speed3*1.3;
			qCalc3.innerHTML = '이동속도 증가 시간 : '+3+'초';
			qCalc4.innerHTML = '재사용 대기시간 : '+(8*(1-coolDown3)).toFixed(1)+'초';
		}
		if(qLevel==5){
			qCalc1.innerHTML = '데미지 : '+(150+(1.4*attack3));
			qCalc2.innerHTML = '이동속도 30% 증가 : '+speed3*1.3;
			qCalc3.innerHTML = '이동속도 증가 시간 : '+3.5+'초';
			qCalc4.innerHTML = '재사용 대기시간 : '+(8*(1-coolDown3)).toFixed(1)+'초';
		}
	}
	if(chName=="갈리오") {
		if(qLevel==1){
			qCalc1.innerHTML = '돌풍 피해 : '+(80+(0.75*spell3))+' | 1틱 당 소용돌이 피해 : 피격 대상 최대 체력의 '+(2+(0.0066*spell3))+'%';
			qCalc2.innerHTML = '총 피해량 : '+(80+(0.75*spell3))+' 대상 체력의'+(6+(0.02*spell3))+'%';
			qCalc3.innerHTML = '마나 소모 : '+70;
			qCalc4.innerHTML = '재사용 대기시간 : '+(12*(1-coolDown3)).toFixed(1)+'초';
		}
		if(qLevel==2){
			qCalc1.innerHTML = '돌풍 피해 : '+(115+(0.75*spell3))+' | 1틱 당 소용돌이 피해 : 피격 대상 최대 체력의 '+(2+(0.0066*spell3))+'%';
			qCalc2.innerHTML = '총 피해량 : '+(115+(0.75*spell3))+' 대상 체력의'+(6+(0.02*spell3))+'%';
			qCalc3.innerHTML = '마나 소모 : '+75;
			qCalc4.innerHTML = '재사용 대기시간 : '+(11.5*(1-coolDown3)).toFixed(1)+'초';
		}
		if(qLevel==3){
			qCalc1.innerHTML = '돌풍 피해 : '+(150+(0.75*spell3))+' | 1틱 당 소용돌이 피해 : 피격 대상 최대 체력의 '+(2+(0.0066*spell3))+'%';
			qCalc2.innerHTML = '총 피해량 : '+(150+(0.75*spell3))+' 대상 체력의'+(6+(0.02*spell3))+'%';
			qCalc3.innerHTML = '마나 소모 : '+80;
			qCalc4.innerHTML = '재사용 대기시간 : '+(11*(1-coolDown3)).toFixed(1)+'초';
		}
		if(qLevel==4){
			qCalc1.innerHTML = '돌풍 피해 : '+(185+(0.75*spell3))+' | 1틱 당 소용돌이 피해 : 피격 대상 최대 체력의 '+(2+(0.0066*spell3))+'%';
			qCalc2.innerHTML = '총 피해량 : '+(185+(0.75*spell3))+' 대상 체력의'+(6+(0.02*spell3))+'%';
			qCalc3.innerHTML = '마나 소모 : '+85;
			qCalc4.innerHTML = '재사용 대기시간 : '+(10.5*(1-coolDown3)).toFixed(1)+'초';
		}
		if(qLevel==5){
			qCalc1.innerHTML = '돌풍 피해 : '+(220+(0.75*spell3))+' | 1틱 당 소용돌이 피해 : 피격 대상 최대 체력의 '+(2+(0.0066*spell3))+'%';
			qCalc2.innerHTML = '총 피해량 : '+(220+(0.75*spell3))+' 대상 체력의'+(6+(0.02*spell3))+'%';
			qCalc3.innerHTML = '마나 소모 : '+90;
			qCalc4.innerHTML = '재사용 대기시간 : '+(10*(1-coolDown3)).toFixed(1)+'초';
		}
	}
	if(chName=="루시안") {
		if(qLevel==1){
			qCalc1.innerHTML = '데미지 : '+(85+(0.6*attack3)).toFixed(1);
			qCalc2.innerHTML = '마나 소모 : '+50;
			qCalc3.innerHTML = '재사용 대기시간  : '+9*(1-coolDown3).toFixed(1)+'초';
		}
		if(qLevel==2){
			qCalc1.innerHTML = '데미지 : '+(120+(0.75*attack3)).toFixed(1);
			qCalc2.innerHTML = '마나 소모 : '+60;
			qCalc3.innerHTML = '재사용 대기시간  : '+8*(1-coolDown3).toFixed(1)+'초';
		}
		if(qLevel==3){
			qCalc1.innerHTML = '데미지 : '+(155+(0.9*attack3)).toFixed(1);
			qCalc2.innerHTML = '마나 소모 : '+70;
			qCalc3.innerHTML = '재사용 대기시간  : '+7*(1-coolDown3).toFixed(1)+'초';
		}
		if(qLevel==4){
			qCalc1.innerHTML = '데미지 : '+(190+(1.05*attack3)).toFixed(1);
			qCalc2.innerHTML = '마나 소모 : '+80;
			qCalc3.innerHTML = '재사용 대기시간  : '+6*(1-coolDown3).toFixed(1)+'초';
		}
		if(qLevel==5){
			qCalc1.innerHTML = '데미지 : '+(225+(1.2*attack3)).toFixed(1);
			qCalc2.innerHTML = '마나 소모 : '+90;
			qCalc3.innerHTML = '재사용 대기시간  : '+5*(1-coolDown3).toFixed(1)+'초';
		}
	}
	if(chName=="아칼리") {
		if(qLevel==1){
			qCalc1.innerHTML = '데미지 : '+(25+(0.65*attack3)+(0.6*spell3)).toFixed(1);
			qCalc2.innerHTML = '기력 소모 : '+100;
		}
		if(qLevel==2){
			qCalc1.innerHTML = '데미지 : '+(50+(0.65*attack3)+(0.6*spell3)).toFixed(1);
			qCalc2.innerHTML = '기력 소모 : '+95;
		}
		if(qLevel==3){
			qCalc1.innerHTML = '데미지 : '+(75+(0.65*attack3)+(0.6*spell3)).toFixed(1);
			qCalc2.innerHTML = '기력 소모 : '+90;
		}
		if(qLevel==4){
			qCalc1.innerHTML = '데미지 : '+(100+(0.65*attack3)+(0.6*spell3)).toFixed(1);
			qCalc2.innerHTML = '기력 소모 : '+85;
		}
		if(qLevel==5){
			qCalc1.innerHTML = '데미지 : '+(125+(0.65*attack3)+(0.6*spell3)).toFixed(1);
			qCalc2.innerHTML = '기력 소모 : '+80;
		}
	}
	if(chName=="잔나") {
		if(qLevel==1){
			qCalc1.innerHTML = '기본 마법피해  : '+(60+(0.35*spell3)).toFixed(1)+' | 1초 충전 당 추가 마법피해 : '+(15+(0.1*spell3)).toFixed(1)+' | 최대 마법피해 : '+(105+(0.65*spell3)).toFixed(1);
			qCalc2.innerHTML = '마나 소모 : '+60;
			qCalc3.innerHTML = '재사용 대기시간 : '+(14*(1-coolDown3)).toFixed(1)+'초';
		}
		if(qLevel==2){
			qCalc1.innerHTML = '기본 마법피해  : '+(85+(0.35*spell3)).toFixed(1)+' | 1초 충전 당 추가 마법피해 : '+(20+(0.1*spell3)).toFixed(1)+' | 최대 마법피해 : '+(145+(0.65*spell3)).toFixed(1);
			qCalc2.innerHTML = '마나 소모 : '+60;
			qCalc3.innerHTML = '재사용 대기시간 : '+(13*(1-coolDown3)).toFixed(1)+'초';
		}
		if(qLevel==3){
			qCalc1.innerHTML = '기본 마법피해  : '+(110+(0.35*spell3)).toFixed(1)+' | 1초 충전 당 추가 마법피해 : '+(25+(0.1*spell3)).toFixed(1)+' | 최대 마법피해 : '+(185+(0.65*spell3)).toFixed(1);
			qCalc2.innerHTML = '마나 소모 : '+60;
			qCalc3.innerHTML = '재사용 대기시간 : '+(12*(1-coolDown3)).toFixed(1)+'초';
		}
		if(qLevel==4){
			qCalc1.innerHTML = '기본 마법피해  : '+(135+(0.35*spell3)).toFixed(1)+' | 1초 충전 당 추가 마법피해 : '+(30+(0.1*spell3)).toFixed(1)+' | 최대 마법피해 : '+(215+(0.65*spell3)).toFixed(1);
			qCalc2.innerHTML = '마나 소모 : '+60;
			qCalc3.innerHTML = '재사용 대기시간 : '+(11*(1-coolDown3)).toFixed(1)+'초';
		}
		if(qLevel==5){
			qCalc1.innerHTML = '기본 마법피해  : '+(160+(0.35*spell3)).toFixed(1)+' | 1초 충전 당 추가 마법피해 : '+(35+(0.1*spell3)).toFixed(1)+' | 최대 마법피해 : '+(245+(0.65*spell3)).toFixed(1);
			qCalc2.innerHTML = '마나 소모 : '+60;
			qCalc3.innerHTML = '재사용 대기시간 : '+(10*(1-coolDown3)).toFixed(1)+'초';
		}
	}	
}

function wCalc() {
	let chName = document.getElementById("champName").childNodes[0].nodeValue;
	let chLevel = Number(document.getElementsByClassName('champLevel')[0].value);
	let wLevel = Number(document.getElementsByClassName('wLevel')[0].value);
	
	let wCalc1 = document.getElementById('wCalc1'),
		wCalc2 = document.getElementById('wCalc2'),
		wCalc3 = document.getElementById('wCalc3'),
		wCalc4 = document.getElementById('wCalc4'),
		wCalc5 = document.getElementById('wCalc5'),
		wCalc6 = document.getElementById('wCalc6');

	let hp3 = Number(document.getElementById('hp3').childNodes[0].nodeValue),
	    hpRecovery3 = Number(document.getElementById('hpRecovery3').childNodes[0].nodeValue),
	   	resources3 = Number(document.getElementById('resources3').childNodes[0].nodeValue),
	   	resourcesRecovery3 = Number(document.getElementById('resourcesRecovery3').childNodes[0].nodeValue),
	   	attack3 = Number(document.getElementById('attack3').childNodes[0].nodeValue),
	   	attackSpeed3 = Number(document.getElementById('attackSpeed3').childNodes[0].nodeValue),
	   	defense3 = Number(document.getElementById('defense3').childNodes[0].nodeValue),
	   	magicDefense3 = Number(document.getElementById('magicDefense3').childNodes[0].nodeValue),
	   	range3 = Number(document.getElementById('range3').childNodes[0].nodeValue),
	   	speed3 = Number(document.getElementById('speed3').childNodes[0].nodeValue),
	   	spell3 = Number(document.getElementById('spell3').childNodes[0].nodeValue);
		coolDown3 = Number(document.getElementById('coolDown3').childNodes[0].nodeValue);
	
	if(chName=="가렌") {
		if(wLevel==1){
			wCalc1.innerHTML = '보호막 : '+(hp3*0.1).toFixed(1);
			wCalc2.innerHTML = '물리/마법피해량 30% 감소 시간 : '+2+'초';
			wCalc3.innerHTML = '재사용 대기시간 : '+(24*(1-coolDown3)).toFixed(1)+'초';
		}
		if(wLevel==2){
			wCalc1.innerHTML = '보호막 : '+(hp3*0.1).toFixed(1);
			wCalc2.innerHTML = '물리/마법피해량 30% 감소 시간 : '+2.75+'초';
			wCalc3.innerHTML = '재사용 대기시간 : '+(23*(1-coolDown3)).toFixed(1)+'초';
		}
		if(wLevel==3){
			wCalc1.innerHTML = '보호막 : '+(hp3*0.1).toFixed(1);
			wCalc2.innerHTML = '물리/마법피해량 30% 감소 시간 : '+3.5+'초';
			wCalc3.innerHTML = '재사용 대기시간 : '+(22*(1-coolDown3)).toFixed(1)+'초';
		}
		if(wLevel==4){
			wCalc1.innerHTML = '보호막 : '+(hp3*0.1).toFixed(1);
			wCalc2.innerHTML = '물리/마법피해량 30% 감소 시간 : '+4.25+'초';
			wCalc3.innerHTML = '재사용 대기시간 : '+(21*(1-coolDown3)).toFixed(1)+'초';
		}
		if(wLevel==5){
			wCalc1.innerHTML = '보호막 : '+(hp3*0.1).toFixed(1);
			wCalc2.innerHTML = '물리/마법피해량 30% 감소 시간 : '+5+'초';
			wCalc3.innerHTML = '재사용 대기시간 : '+(20*(1-coolDown3)).toFixed(1)+'초';
		}
	}
	if(chName=="갈리오") {
		if(wLevel==1){
			wCalc1.innerHTML = '보호막 : '+(0.08*hp3).toFixed(1);
			wCalc2.innerHTML = '마법저항력 증가 : '+(20+(0.08*magicDefense3)+(0.05*spell3))+'% /방어력 증가 : '+(10+(0.04*magicDefense3)+(0.025*spell3));
			wCalc3.innerHTML = '최소 피해 : '+(20+(spell3*0.3)).toFixed(1)+' / 최대 피해 : '+(60+(spell3*0.9)).toFixed(1);
			wCalc4.innerHTML = '재사용 대기시간 : '+(16*(1-coolDown3)).toFixed(1)+'초';
		}
		if(wLevel==2){
			wCalc1.innerHTML = '보호막 : '+(0.11*hp3).toFixed(1);
			wCalc2.innerHTML = '마법저항력 증가 : '+(25+(0.08*magicDefense3)+(0.05*spell3))+'% /방어력 증가 : '+(12.5+(0.04*magicDefense3)+(0.025*spell3))+'%';
			wCalc3.innerHTML = '최소 피해 : '+(35+(spell3*0.3)).toFixed(1)+' / 최대 피해 : '+(105+(spell3*0.9)).toFixed(1);
			wCalc4.innerHTML = '재사용 대기시간 : '+(15*(1-coolDown3)).toFixed(1)+'초';
		}
		if(wLevel==3){
			wCalc1.innerHTML = '보호막 : '+(0.14*hp3).toFixed(1);
			wCalc2.innerHTML = '마법저항력 증가 : '+(30+(0.08*magicDefense3)+(0.05*spell3))+'% /방어력 증가 : '+(15+(0.04*magicDefense3)+(0.025*spell3))+'%';
			wCalc3.innerHTML = '최소 피해 : '+(50+(spell3*0.3)).toFixed(1)+' / 최대 피해 : '+(150+(spell3*0.9)).toFixed(1);
			wCalc4.innerHTML = '재사용 대기시간 : '+(14*(1-coolDown3)).toFixed(1)+'초';
		}
		if(wLevel==4){
			wCalc1.innerHTML = '보호막 : '+(0.17*hp3).toFixed(1);
			wCalc2.innerHTML = '마법저항력 증가 : '+(35+(0.08*magicDefense3)+(0.05*spell3))+'% /방어력 증가 : '+(17.5+(0.04*magicDefense3)+(0.025*spell3))+'%';
			wCalc3.innerHTML = '최소 피해 : '+(65+(spell3*0.3)).toFixed(1)+' / 최대 피해 : '+(195+(spell3*0.9)).toFixed(1);
			wCalc4.innerHTML = '재사용 대기시간 : '+(13*(1-coolDown3)).toFixed(1)+'초';
		}
		if(wLevel==5){
			wCalc1.innerHTML = '보호막 : '+(0.2*hp3).toFixed(1);
			wCalc2.innerHTML = '마법저항력 증가 : '+(40+(0.08*magicDefense3)+(0.05*spell3))+'% /방어력 증가 : '+(20+(0.04*magicDefense3)+(0.025*spell3))+'%';
			wCalc3.innerHTML = '최소 피해 : '+(80+(spell3*0.3)).toFixed(1)+' / 최대 피해 : '+(240+(spell3*0.9)).toFixed(1);
			wCalc4.innerHTML = '재사용 대기시간 : '+(12*(1-coolDown3)).toFixed(1)+'초';
		}
	}
	if(chName=="루시안") {
		if(wLevel==1){
			wCalc1.innerHTML = '데미지 : '+(75+(spell3*0.9)).toFixed(1);
			wCalc2.innerHTML = '스킬 사용 후 이동속도 : '+(speed3+60);
			wCalc3.innerHTML = '재사용 대기시간 : '+(14*(1-coolDown3)).toFixed(1)+'초';
		}
		if(wLevel==2){
			wCalc1.innerHTML = '데미지 : '+(110+(spell3*0.9)).toFixed(1);
			wCalc2.innerHTML = '스킬 사용 후 이동속도 : '+(speed3+65);
			wCalc3.innerHTML = '재사용 대기시간 : '+(13*(1-coolDown3)).toFixed(1)+'초';
		}
		if(wLevel==3){
			wCalc1.innerHTML = '데미지 : '+(145+(spell3*0.9)).toFixed(1);
			wCalc2.innerHTML = '스킬 사용 후 이동속도 : '+(speed3+70);
			wCalc3.innerHTML = '재사용 대기시간 : '+(12*(1-coolDown3)).toFixed(1)+'초';
		}
		if(wLevel==4){
			wCalc1.innerHTML = '데미지 : '+(180+(spell3*0.9)).toFixed(1);
			wCalc2.innerHTML = '스킬 사용 후 이동속도 : '+(speed3+75);
			wCalc3.innerHTML = '재사용 대기시간 : '+(11*(1-coolDown3)).toFixed(1)+'초';
		}
		if(wLevel==5){
			wCalc1.innerHTML = '데미지 : '+(215+(spell3*0.9)).toFixed(1);
			wCalc2.innerHTML = '스킬 사용 후 이동속도 : '+(speed3+80);
			wCalc3.innerHTML = '재사용 대기시간 : '+(10*(1-coolDown3)).toFixed(1)+'초';
		}
	}
	if(chName=="아칼리") {
		if(wLevel==1){
			wCalc1.innerHTML = '이동속도 증가 : '+(speed3*1.2).toFixed(1);
			wCalc2.innerHTML = '연막 지속시간 : '+5;
		}
		if(wLevel==2){
			wCalc1.innerHTML = '이동속도 증가 : '+(speed3*1.25).toFixed(1);
			wCalc2.innerHTML = '연막 지속시간 : '+5.5;
		}
		if(wLevel==3){
			wCalc1.innerHTML = '이동속도 증가 : '+(speed3*1.3).toFixed(1);
			wCalc2.innerHTML = '연막 지속시간 : '+6;
		}
		if(wLevel==4){
			wCalc1.innerHTML = '이동속도 증가 : '+(speed3*1.35).toFixed(1);
			wCalc2.innerHTML = '연막 지속시간 : '+6.5;
		}
		if(wLevel==5){
			wCalc1.innerHTML = '이동속도 증가 : '+(speed3*1.4).toFixed(1);
			wCalc2.innerHTML = '연막 지속시간 : '+7;
		}
	}
	if(chName=="잔나") {
		if(wLevel==1){
			wCalc1.innerHTML = '추가되는 이동속도  : '+(speed3*(0.06+(spell3*0.02))).toFixed(1);
			wCalc2.innerHTML = '데미지  : '+(55+(spell3*0.5)).toFixed(1);
			wCalc3.innerHTML = '마나 소모 : '+50;
			wCalc4.innerHTML = '재사용 대기시간 : '+(8*(1-coolDown3)).toFixed(1)+'초';
			wCalc5.innerHTML = '둔화 : '+(24+(spell3*0.06)).toFixed(1)+'%';
		}
		if(wLevel==2){
			wCalc1.innerHTML = '추가되는 이동속도  : '+(speed3*(0.07+(spell3*0.02))).toFixed(1);
			wCalc2.innerHTML = '데미지  : '+(90+(spell3*0.5)).toFixed(1);
			wCalc3.innerHTML = '마나 소모 : '+60;
			wCalc4.innerHTML = '재사용 대기시간 : '+(7.5*(1-coolDown3)).toFixed(1)+'초';
			wCalc5.innerHTML = '둔화 : '+(28+(spell3*0.06)).toFixed(1)+'%';
		}
		if(wLevel==3){
			wCalc1.innerHTML = '추가되는 이동속도  : '+(speed3*(0.08+(spell3*0.02))).toFixed(1);
			wCalc2.innerHTML = '데미지  : '+(125+(spell3*0.5)).toFixed(1);
			wCalc3.innerHTML = '마나 소모 : '+70;
			wCalc4.innerHTML = '재사용 대기시간 : '+(7*(1-coolDown3)).toFixed(1)+'초';
			wCalc5.innerHTML = '둔화 : '+(32+(spell3*0.06)).toFixed(1)+'%';
		}
		if(wLevel==4){
			wCalc1.innerHTML = '추가되는 이동속도  : '+(speed3*(0.09+(spell3*0.02))).toFixed(1);
			wCalc2.innerHTML = '데미지  : '+(160+(spell3*0.5)).toFixed(1);
			wCalc3.innerHTML = '마나 소모 : '+80;
			wCalc4.innerHTML = '재사용 대기시간 : '+(6.5*(1-coolDown3)).toFixed(1)+'초';
			wCalc5.innerHTML = '둔화 : '+(36+(spell3*0.06)).toFixed(1)+'%';
		}
		if(wLevel==5){
			wCalc1.innerHTML = '추가되는 이동속도  : '+(speed3*(0.1+(spell3*0.02))).toFixed(1);
			wCalc2.innerHTML = '데미지  : '+(195+(spell3*0.5)).toFixed(1);
			wCalc3.innerHTML = '마나 소모 : '+90;
			wCalc4.innerHTML = '재사용 대기시간 : '+(6*(1-coolDown3)).toFixed(1)+'초';
			wCalc5.innerHTML = '둔화 : '+(40+(spell3*0.06)).toFixed(1)+'%';
		}
	}
}

function eCalc() {
	let chName = document.getElementById("champName").childNodes[0].nodeValue;
	let chLevel = Number(document.getElementsByClassName('champLevel')[0].value);
	let eLevel = Number(document.getElementsByClassName('eLevel')[0].value);
	
	let eCalc1 = document.getElementById('eCalc1'),
		eCalc2 = document.getElementById('eCalc2'),
		eCalc3 = document.getElementById('eCalc3'),
		eCalc4 = document.getElementById('eCalc4'),
		eCalc5 = document.getElementById('eCalc5'),
		eCalc6 = document.getElementById('eCalc6');

	let hp3 = Number(document.getElementById('hp3').childNodes[0].nodeValue),
	    hpRecovery3 = Number(document.getElementById('hpRecovery3').childNodes[0].nodeValue),
	   	resources3 = Number(document.getElementById('resources3').childNodes[0].nodeValue),
	   	resourcesRecovery3 = Number(document.getElementById('resourcesRecovery3').childNodes[0].nodeValue),
	   	attack3 = Number(document.getElementById('attack3').childNodes[0].nodeValue),
	   	attackSpeed3 = Number(document.getElementById('attackSpeed3').childNodes[0].nodeValue),
	   	defense3 = Number(document.getElementById('defense3').childNodes[0].nodeValue),
	   	magicDefense3 = Number(document.getElementById('magicDefense3').childNodes[0].nodeValue),
	   	range3 = Number(document.getElementById('range3').childNodes[0].nodeValue),
	   	speed3 = Number(document.getElementById('speed3').childNodes[0].nodeValue),
	   	spell3 = Number(document.getElementById('spell3').childNodes[0].nodeValue);
		coolDown3 = Number(document.getElementById('coolDown3').childNodes[0].nodeValue);
		
	if(chName=="가렌") {
		if(attackSpeed3<0.25){
			eCalc1.innerHTML = '회전수 : 7';
		} else if(attackSpeed3<0.5){
			eCalc1.innerHTML = '회전수 : 8';
		} else if(attackSpeed3<0.75){
			eCalc1.innerHTML = '회전수 : 9';
		} else if(attackSpeed3<1.0){
			eCalc1.innerHTML = '회전수 : 10';
		} else if(attackSpeed3<1.25){
			eCalc1.innerHTML = '회전수 : 11';
		} else if(attackSpeed3<1.5){
			eCalc1.innerHTML = '회전수 : 12';
		} else if(attackSpeed3<1.75){
			eCalc1.innerHTML = '회전수 : 13';
		} else if(attackSpeed3<2.0){
			eCalc1.innerHTML = '회전수 : 14';
		}
		if(eLevel==1){
			eCalc2.innerHTML = '최대 데미지 : '+(4+(0.32*attack3)).toFixed(1)+'* 회전수';
			eCalc3.innerHTML = '재사용 대기시간 : '+9*(1-coolDown3)+'초';
		}
		if(eLevel==2){
			eCalc2.innerHTML = '최대 데미지 : '+(8+(0.34*attack3)).toFixed(1)+'* 회전수';
			eCalc3.innerHTML = '재사용 대기시간 : '+9*(1-coolDown3)+'초';
		}
		if(eLevel==3){
			eCalc2.innerHTML = '최대 데미지 : '+(12+(0.36*attack3)).toFixed(1)+'* 회전수';
			eCalc3.innerHTML = '재사용 대기시간 : '+9*(1-coolDown3)+'초';
		}
		if(eLevel==4){
			eCalc2.innerHTML = '최대 데미지 : '+(16+(0.38*attack3)).toFixed(1)+'* 회전수';
			eCalc3.innerHTML = '재사용 대기시간 : '+9*(1-coolDown3)+'초';
		}
		if(eLevel==5){
			eCalc2.innerHTML = '최대 데미지 : '+(20+(0.4*attack3)).toFixed(1)+'* 회전수';
			eCalc3.innerHTML = '재사용 대기시간 : '+9*(1-coolDown3)+'초';
		}
	}
	if(chName=="갈리오") {
		if(eLevel==1){
			eCalc1.innerHTML = '데미지 : '+(90+(spell3*0.9));
			eCalc2.innerHTML = '재사용 대기시간 : '+14*(1-coolDown3).toFixed(1);
		}
		if(eLevel==2){
			eCalc1.innerHTML = '데미지 : '+(130+(spell3*0.9));
			eCalc2.innerHTML = '재사용 대기시간 : '+13*(1-coolDown3).toFixed(1);
		}
		if(eLevel==3){
			eCalc1.innerHTML = '데미지 : '+(170+(spell3*0.9));
			eCalc2.innerHTML = '재사용 대기시간 : '+12*(1-coolDown3).toFixed(1);
		}
		if(eLevel==4){
			eCalc1.innerHTML = '데미지 : '+(210+(spell3*0.9));
			eCalc2.innerHTML = '재사용 대기시간 : '+11*(1-coolDown3).toFixed(1);
		}
		if(eLevel==5){
			eCalc1.innerHTML = '데미지 : '+(250+(spell3*0.9));
			eCalc2.innerHTML = '재사용 대기시간 : '+10*(1-coolDown3).toFixed(1);
		}
	}
	if(chName=="루시안") {
		if(eLevel==1){
			eCalc1.innerHTML = '마나 소모 : '+40;
			eCalc2.innerHTML = '재사용 대기시간 : '+22*(1-coolDown3).toFixed(1);
		}
		if(eLevel==2){
			eCalc1.innerHTML = '마나 소모 : '+30;
			eCalc2.innerHTML = '재사용 대기시간 : '+20*(1-coolDown3).toFixed(1);
		}
		if(eLevel==3){
			eCalc1.innerHTML = '마나 소모 : '+20;
			eCalc2.innerHTML = '재사용 대기시간 : '+18*(1-coolDown3).toFixed(1);
		}
		if(eLevel==4){
			eCalc1.innerHTML = '마나 소모 : '+10;
			eCalc2.innerHTML = '재사용 대기시간 : '+16*(1-coolDown3).toFixed(1);
		}
		if(eLevel==5){
			eCalc1.innerHTML = '마나 소모 : '+0;
			eCalc2.innerHTML = '재사용 대기시간 : '+14*(1-coolDown3).toFixed(1);
		}
	}
	if(chName=="아칼리") {
		if(eLevel==1){
			eCalc1.innerHTML = '첫사용시 데미지 : '+(40+(0.35*attack3)+(0.5*spell3)).toFixed(1);
			eCalc2.innerHTML = '재사용시 데미지 : '+(40+(0.35*attack3)+(0.5*spell3)).toFixed(1);
			eCalc3.innerHTML = '재사용 대기시간 : '+16*(1-coolDown3).toFixed(1);
		}
		if(eLevel==2){
			eCalc1.innerHTML = '첫사용시 데미지 : '+(70+(0.35*attack3)+(0.5*spell3)).toFixed(1);
			eCalc2.innerHTML = '재사용시 데미지 : '+(70+(0.35*attack3)+(0.5*spell3)).toFixed(1);
			eCalc3.innerHTML = '재사용 대기시간 : '+14.5*(1-coolDown3).toFixed(1);
		}
		if(eLevel==3){
			eCalc1.innerHTML = '첫사용시 데미지 : '+(100+(0.35*attack3)+(0.5*spell3)).toFixed(1);
			eCalc2.innerHTML = '재사용시 데미지 : '+(100+(0.35*attack3)+(0.5*spell3)).toFixed(1);
			eCalc3.innerHTML = '재사용 대기시간 : '+13*(1-coolDown3).toFixed(1);
		}
		if(eLevel==4){
			eCalc1.innerHTML = '첫사용시 데미지 : '+(130+(0.35*attack3)+(0.5*spell3)).toFixed(1);
			eCalc2.innerHTML = '재사용시 데미지 : '+(130+(0.35*attack3)+(0.5*spell3)).toFixed(1);
			eCalc3.innerHTML = '재사용 대기시간 : '+11.5*(1-coolDown3).toFixed(1);
		}
		if(eLevel==5){
			eCalc1.innerHTML = '첫사용시 데미지 : '+(160+(0.35*attack3)+(0.5*spell3)).toFixed(1);
			eCalc2.innerHTML = '재사용시 데미지 : '+(160+(0.35*attack3)+(0.5*spell3)).toFixed(1);
			eCalc3.innerHTML = '재사용 대기시간 : '+10*(1-coolDown3).toFixed(1);
		}
	}
	if(chName=="잔나") {
		if(eLevel==1){
			eCalc1.innerHTML = '보호막  : '+(80+(spell3*0.7)).toFixed(1);
			eCalc2.innerHTML = '공격력 증가  : '+(10+(spell3*0.1)).toFixed(1);
			eCalc3.innerHTML = '마나 소모 : '+70;
			eCalc4.innerHTML = '재사용 대기시간 : '+(16*(1-coolDown3)).toFixed(1)+'초';
		}
		if(eLevel==2){
			eCalc1.innerHTML = '보호막  : '+(115+(spell3*0.7)).toFixed(1);
			eCalc2.innerHTML = '공격력 증가  : '+(17.5+(spell3*0.1)).toFixed(1);
			eCalc3.innerHTML = '마나 소모 : '+80;
			eCalc4.innerHTML = '재사용 대기시간 : '+(15*(1-coolDown3)).toFixed(1)+'초';
		}
		if(eLevel==3){
			eCalc1.innerHTML = '보호막  : '+(150+(spell3*0.7)).toFixed(1);
			eCalc2.innerHTML = '공격력 증가  : '+(25+(spell3*0.1)).toFixed(1);
			eCalc3.innerHTML = '마나 소모 : '+90;
			eCalc4.innerHTML = '재사용 대기시간 : '+(14*(1-coolDown3)).toFixed(1)+'초';
		}
		if(eLevel==4){
			eCalc1.innerHTML = '보호막  : '+(185+(spell3*0.7)).toFixed(1);
			eCalc2.innerHTML = '공격력 증가  : '+(32.5+(spell3*0.1)).toFixed(1);
			eCalc3.innerHTML = '마나 소모 : '+100;
			eCalc4.innerHTML = '재사용 대기시간 : '+(13*(1-coolDown3)).toFixed(1)+'초';
		}
		if(eLevel==5){
			eCalc1.innerHTML = '보호막  : '+(220+(spell3*0.7)).toFixed(1);
			eCalc2.innerHTML = '공격력 증가  : '+(40+(spell3*0.1)).toFixed(1);
			eCalc3.innerHTML = '마나 소모 : '+110;
			eCalc4.innerHTML = '재사용 대기시간 : '+(12*(1-coolDown3)).toFixed(1)+'초';
		}
	}
}

function rCalc() {
	let chName = document.getElementById("champName").childNodes[0].nodeValue;
	let chLevel = Number(document.getElementsByClassName('champLevel')[0].value);
	let rLevel = Number(document.getElementsByClassName('rLevel')[0].value);
	
	let rCalc1 = document.getElementById('rCalc1'),
		rCalc2 = document.getElementById('rCalc2'),
		rCalc3 = document.getElementById('rCalc3'),
		rCalc4 = document.getElementById('rCalc4'),
		rCalc5 = document.getElementById('rCalc5'),
		rCalc6 = document.getElementById('rCalc6');

	let hp3 = Number(document.getElementById('hp3').childNodes[0].nodeValue),
	    hpRecovery3 = Number(document.getElementById('hpRecovery3').childNodes[0].nodeValue),
	   	resources3 = Number(document.getElementById('resources3').childNodes[0].nodeValue),
	   	resourcesRecovery3 = Number(document.getElementById('resourcesRecovery3').childNodes[0].nodeValue),
	   	attack3 = Number(document.getElementById('attack3').childNodes[0].nodeValue),
	   	attackSpeed3 = Number(document.getElementById('attackSpeed3').childNodes[0].nodeValue),
	   	defense3 = Number(document.getElementById('defense3').childNodes[0].nodeValue),
	   	magicDefense3 = Number(document.getElementById('magicDefense3').childNodes[0].nodeValue),
	   	range3 = Number(document.getElementById('range3').childNodes[0].nodeValue),
	   	speed3 = Number(document.getElementById('speed3').childNodes[0].nodeValue),
	   	spell3 = Number(document.getElementById('spell3').childNodes[0].nodeValue);
		coolDown3 = Number(document.getElementById('coolDown3').childNodes[0].nodeValue);
	
	if(chName=="가렌") {
		if(rLevel==1){
			rCalc1.innerHTML = '데미지 : 150+(적의 잃은 체력의 20%)';
			rCalc2.innerHTML = '재사용 대기시간 : '+(120*(1-coolDown3)).toFixed(1)+'초';
		}
		if(rLevel==2){
			rCalc1.innerHTML = '데미지 : 300+(적의 잃은 체력의 25%)';
			rCalc2.innerHTML = '재사용 대기시간 : '+(100*(1-coolDown3)).toFixed(1)+'초';
		}
		if(rLevel==3){
			rCalc1.innerHTML = '데미지 : 450+(적의 잃은 체력의 30%)';
			rCalc2.innerHTML = '재사용 대기시간 : '+(80*(1-coolDown3)).toFixed(1)+'초';
		}
		
	}
	if(chName=="갈리오") {
		if(rLevel==1){
			rCalc1.innerHTML = '사거리 : '+4000;
			rCalc2.innerHTML = '데미지 : '+(150+(spell3*0.6)).toFixed(1);
			rCalc3.innerHTML = '재사용 대기시간 : '+(200*(1-coolDown3)).toFixed(1)+'초';
		}
		if(rLevel==2){
			rCalc1.innerHTML = '사거리 : '+4750;
			rCalc2.innerHTML = '데미지 : '+(250+(spell3*0.6)).toFixed(1);
			rCalc3.innerHTML = '재사용 대기시간 : '+(180*(1-coolDown3)).toFixed(1)+'초';
		}
		if(rLevel==3){
			rCalc1.innerHTML = '사거리 : '+5500;
			rCalc2.innerHTML = '데미지 : '+(350+(spell3*0.6)).toFixed(1);
			rCalc3.innerHTML = '재사용 대기시간 : '+(160*(1-coolDown3)).toFixed(1)+'초';
		}
		
	}
	if(chName=="루시안") {
		if(rLevel==1){
			rCalc1.innerHTML = '발당 데미지 : '+(20+(attack3*0.25)+(spell3*0.1)).toFixed(1);
			rCalc2.innerHTML = '최대 피해량 : '+((20+(attack3*0.25)+(spell3*0.1))*20).toFixed(1);
			rCalc3.innerHTML = '재사용 대기시간 : '+(110*(1-coolDown3)).toFixed(1)+'초';
		}
		if(rLevel==2){
			rCalc1.innerHTML = '발당 데미지 : '+(40+(attack3*0.25)+(spell3*0.1)).toFixed(1);
			rCalc2.innerHTML = '최대 피해량 : '+((40+(attack3*0.25)+(spell3*0.1))*25).toFixed(1);
			rCalc3.innerHTML = '재사용 대기시간 : '+(100*(1-coolDown3)).toFixed(1)+'초';
		}
		if(rLevel==3){
			rCalc1.innerHTML = '발당 데미지 : '+(60+(attack3*0.25)+(spell3*0.1)).toFixed(1);
			rCalc2.innerHTML = '최대 피해량 : '+((60+(attack3*0.25)+(spell3*0.1))*30).toFixed(1);
			rCalc3.innerHTML = '재사용 대기시간 : '+(90*(1-coolDown3)).toFixed(1)+'초';
		}
		
	}
	if(chName=="아칼리") {
		if(rLevel==1){
			rCalc1.innerHTML = '첫사용시 데미지 : '+(85+(0.5*attack3)).toFixed(1);
			rCalc2.innerHTML = '재사용 대기시간 : '+(160*(1-coolDown3)).toFixed(1);
			rCalc3.innerHTML = '재사용시  최소 데미지 : '+(85+(0.3*spell3)).toFixed(1);
			rCalc4.innerHTML = '재사용시  최대 데미지 : '+(255+(0.9*spell3)).toFixed(1);
		}
		if(rLevel==2){
			rCalc1.innerHTML = '첫사용시 데미지 : '+(150+(0.5*attack3)).toFixed(1);
			rCalc2.innerHTML = '재사용 대기시간 : '+(130*(1-coolDown3)).toFixed(1);
			rCalc3.innerHTML = '재사용시  최소 데미지 : '+(150+(0.3*spell3)).toFixed(1);
			rCalc4.innerHTML = '재사용시  최대 데미지 : '+(450+(0.9*spell3)).toFixed(1);
		}
		if(rLevel==3){
			rCalc1.innerHTML = '첫사용시 데미지 : '+(215+(0.5*attack3)).toFixed(1);
			rCalc2.innerHTML = '재사용 대기시간 : '+(100*(1-coolDown3)).toFixed(1);
			rCalc3.innerHTML = '재사용시  최소 데미지 : '+(215+(0.3*spell3)).toFixed(1);
			rCalc4.innerHTML = '재사용시  최대 데미지 : '+(645+(0.9*spell3)).toFixed(1);
		}
		
	}
	if(chName=="잔나") {
		if(rLevel==1){
			rCalc1.innerHTML = '초당 회복량 : '+(100+(spell3*0.5)).toFixed(1);
			rCalc2.innerHTML = '최대 회복량 : '+(3*(100+(spell3*0.5))).toFixed(1);
			rCalc3.innerHTML = '재사용 대기시간 : '+(150*(1-coolDown3)).toFixed(1)+'초';
		}
		if(rLevel==2){
			rCalc1.innerHTML = '초당 회복량 : '+(150+(spell3*0.5)).toFixed(1);
			rCalc2.innerHTML = '최대 회복량 : '+(3*(150+(spell3*0.5))).toFixed(1);
			rCalc3.innerHTML = '재사용 대기시간 : '+(135*(1-coolDown3)).toFixed(1)+'초';
		}
		if(rLevel==3){
			rCalc1.innerHTML = '초당 회복량 : '+(200+(spell3*0.5)).toFixed(1);
			rCalc2.innerHTML = '최대 회복량 : '+(3*(200+(spell3*0.5))).toFixed(1);
			rCalc3.innerHTML = '재사용 대기시간 : '+(110*(1-coolDown3)).toFixed(1)+'초';
		}
		
	}
}