function levelUp() {
	let champName = document.getElementById("champName").childNodes[0].nodeValue;
    let champLevel = Number(document.getElementsByClassName('champLevel')[0].value);

    let hp = Number(document.getElementById('hp').childNodes[0].nodeValue),
    	hpRecovery = Number(document.getElementById('hpRecovery').childNodes[0].nodeValue),
    	resources = Number(document.getElementById('resources').childNodes[0].nodeValue),
    	resourcesRecovery = Number(document.getElementById('resourcesRecovery').childNodes[0].nodeValue),
    	attack = Number(document.getElementById('attack').childNodes[0].nodeValue),
    	attackSpeed = Number(document.getElementById('attackSpeed').childNodes[0].nodeValue),
    	defense = Number(document.getElementById('defense').childNodes[0].nodeValue),
    	magicDefense = Number(document.getElementById('magicDefense').childNodes[0].nodeValue),
    	range = Number(document.getElementById('range').childNodes[0].nodeValue),
    	speed = Number(document.getElementById('speed').childNodes[0].nodeValue),
    	spell = Number(document.getElementById('spell').childNodes[0].nodeValue);
    
    let hp2 = document.getElementById('hp2'),
    	hpRecovery2 = document.getElementById('hpRecovery2'),
    	resources2 = document.getElementById('resources2'),
    	resourcesRecovery2 = document.getElementById('resourcesRecovery2'),
    	attack2 = document.getElementById('attack2'),
    	attackSpeed2 = document.getElementById('attackSpeed2'),
    	defense2 = document.getElementById('defense2'),
    	magicDefense2 = document.getElementById('magicDefense2'),
    	range2 = document.getElementById('range2'),
    	speed2 = document.getElementById('speed2'),
    	spell2 = document.getElementById('spell2');
    
    if(champName=="가렌"&&champLevel>=1&&champLevel<19) {
    	hp2.innerHTML=hp+84*(champLevel-1);
    	hpRecovery2.innerHTML=hpRecovery+(0.5*(champLevel-1));
		resources2.innerHTML=resources;
		resourcesRecovery2.innerHTML=resourcesRecovery;
		attack2.innerHTML=(attack+(4.5*(champLevel-1))).toFixed(3);
		attackSpeed2.innerHTML=(attackSpeed*(1+0.0365*(champLevel-1))).toFixed(3);
		defense2.innerHTML=defense+(3.0*(champLevel-1));
		magicDefense2.innerHTML=magicDefense+(1.25*(champLevel-1));
		range2.innerHTML=range;
		speed2.innerHTML=speed;
		spell2.innerHTML=spell;
    } else if(champName=="갈리오"&&champLevel>=1&&champLevel<19) {
    	hp2.innerHTML=hp+112*(champLevel-1);
    	hpRecovery2.innerHTML=hpRecovery+(0.8*(champLevel-1));
		resources2.innerHTML=resources+(40*(champLevel-1));
		resourcesRecovery2.innerHTML=resourcesRecovery+(0.7*(champLevel-1));
		attack2.innerHTML=(attack+(3.38*(champLevel-1))).toFixed(3);
		attackSpeed2.innerHTML=(attackSpeed*(1+0.012*(champLevel-1))).toFixed(3);
		defense2.innerHTML=defense+(3.5*(champLevel-1));
		magicDefense2.innerHTML=magicDefense+(1.25*(champLevel-1));
		range2.innerHTML=range;
		speed2.innerHTML=speed;
		spell2.innerHTML=spell;
    } else if(champName=="루시안"&&champLevel>=1&&champLevel<19) {
    	hp2.innerHTML=hp+86*(champLevel-1);
    	hpRecovery2.innerHTML=hpRecovery+(0.65*(champLevel-1));
		resources2.innerHTML=resources+(38*(champLevel-1));
		resourcesRecovery2.innerHTML=resourcesRecovery+(0.14*(champLevel-1));
		attack2.innerHTML=(attack+(2.75*(champLevel-1))).toFixed(3);
		attackSpeed2.innerHTML=(attackSpeed*(1+0.033*(champLevel-1))).toFixed(3);
		defense2.innerHTML=defense+(3.0*(champLevel-1));
		magicDefense2.innerHTML=magicDefense+(0.5*(champLevel-1));
		range2.innerHTML=range;
		speed2.innerHTML=speed;
		spell2.innerHTML=spell;
    } else if(champName=="아칼리"&&champLevel>=1&&champLevel<19) {
    	hp2.innerHTML=hp+95*(champLevel-1);
    	hpRecovery2.innerHTML=hpRecovery+(0.5*(champLevel-1));
		resources2.innerHTML=resources;
		resourcesRecovery2.innerHTML=resourcesRecovery;
		attack2.innerHTML=(attack+(3.3*(champLevel-1))).toFixed(3);
		attackSpeed2.innerHTML=(attackSpeed*(1+0.032*(champLevel-1))).toFixed(3);
		defense2.innerHTML=defense+(3.5*(champLevel-1));
		magicDefense2.innerHTML=magicDefense+(1.25*(champLevel-1));
		range2.innerHTML=range;
		speed2.innerHTML=speed;
		spell2.innerHTML=spell;
    } else if(champName=="잔나"&&champLevel>=1&&champLevel<19) {
    	hp2.innerHTML=hp+70*(champLevel-1);
    	hpRecovery2.innerHTML=(hpRecovery+(0.56*(champLevel-1))).toFixed(3);
    	resources2.innerHTML=resources+(64*(champLevel-1));
		resourcesRecovery2.innerHTML=resourcesRecovery+(0.41*(champLevel-1));
    	attack2.innerHTML=(attack+(1.5*(champLevel-1))).toFixed(3);
		attackSpeed2.innerHTML=(attackSpeed*(1+0.0295*(champLevel-1))).toFixed(3);
		defense2.innerHTML=defense+(3.8*(champLevel-1));
		magicDefense2.innerHTML=magicDefense+(0.5*(champLevel-1));
		range2.innerHTML=range;
		speed2.innerHTML=speed;
		spell2.innerHTML=spell;
    } 
    
    else if(champLevel>=19) {
    	alert("18레벨이 만렙입니다.");
    }
    	
  
    
}