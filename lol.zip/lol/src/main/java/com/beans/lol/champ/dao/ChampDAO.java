package com.beans.lol.champ.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.beans.lol.champ.ChampVO;
import com.beans.lol.common.JDBCUtil;
import java.sql.SQLException;

@Repository("champDAO")
public class ChampDAO {
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	public ChampVO getChamp(ChampVO cvo){
		ChampVO champ = null;
		try {
			conn = JDBCUtil.getConnection();
			String sql ="select*from champ where champ = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cvo.getChamp());
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				champ = new ChampVO();
				champ.setChamp(rs.getString("champ"));
				champ.setHp(rs.getDouble("hp"));
				champ.setResources(rs.getDouble("resources"));
				champ.setResourcesrecovery(rs.getDouble("resourcesrecovery"));
				champ.setHprecovery(rs.getDouble("hprecovery"));
				champ.setAttack(rs.getDouble("attack"));
				champ.setAttackspeed(rs.getDouble("attackspeed"));
				champ.setDefense(rs.getDouble("defense"));
				champ.setMagicdefense(rs.getDouble("magicdefense"));
				champ.setRange(rs.getInt("range"));
				champ.setSpeed(rs.getInt("speed"));
				champ.setSpell(rs.getDouble("spell"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
			return champ;
		
	}
}
