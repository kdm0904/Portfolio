package com.beans.lol;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.beans.lol.service.UserService;
import com.beans.lol.user.UserVO;



@Controller
@RequestMapping("/users")
public class UserController {
	
	private static final Logger logger = (Logger) LoggerFactory.getLogger(UserController.class);

	
	@ModelAttribute("cp")
	public String getContextPath(HttpServletRequest request) {
		return request.getContextPath();
	}
	
	@Autowired
	UserService userService;
	
//	@Autowired
//	BCryptPasswordEncoder passEncoder;
	
		// 회원가입 
		@RequestMapping("/join")
		public String join(UserVO user, Model model) {
			model.addAttribute("user", new UserVO());
			return "/users/join";
		}
		
		@RequestMapping(value = "/joinRequest", method = RequestMethod.POST)
		public String joinRequest(UserVO user) {
			
//			String inputPass = user.getPassword();
//			String pass = passEncoder.encode(inputPass);
//			user.setPassword(pass);
			userService.join(user);
			
			return "redirect:/";
		}
		
		// 로그인 
		@RequestMapping("/login")
		public String login(UserVO user, Model model) {
			model.addAttribute("user", new UserVO());
			return "/users/login";
		}
		
		@RequestMapping(value = "/loginAction", method = RequestMethod.POST)
		public String LoginRequest(UserVO user, HttpSession session, RedirectAttributes rttr) {
			
			UserVO login = userService.login(user);
			
//			boolean passMatch = passEncoder.matches(user.getPassword(), login.getPassword());
//			
//			if(login != null && passMatch) {
//				session.setAttribute("user", login);
//			} else {
//				session.setAttribute("user", null);
//				rttr.addFlashAttribute("msg", false);
//				return "redirect:/users/login";
//			}
			if(login == null) {
				session.setAttribute("user", null);
				rttr.addFlashAttribute("msg", false);
				return "redirect:/users/login";
			} else {
				session.setAttribute("user", login);
			}
			
			return "redirect:/";
		}
		
		
		// 로그아웃
		@RequestMapping("/logOut")
		public String memLogout(UserVO user, HttpSession session) {
			
			session.invalidate();
			
			return "redirect:/";
		}
		
		//유저정보 변경
		@RequestMapping(value="/updateData", method=RequestMethod.GET)
		public ModelAndView updateData(HttpServletRequest request, Model model) {
			model.addAttribute("user", new UserVO());
			
			
			HttpSession session = request.getSession();
			UserVO user = (UserVO) session.getAttribute("user");

			ModelAndView mav = new ModelAndView();
			mav.addObject("user", userService.update(user));

			mav.setViewName("/users/updateData");

			return mav;
		}
		
		@RequestMapping(value = "/updateAction", method = RequestMethod.POST)
		public ModelAndView updateAction(UserVO user, HttpServletRequest request) {
			
			ModelAndView mav = new ModelAndView();
			HttpSession session = request.getSession();
			
//			String inputPass = user.getPassword();
//			String pass = passEncoder.encode(inputPass);
//			user.setPassword(pass);
			UserVO update = userService.update(user);
			if(update == null) {
				mav.setViewName("/users/updateData");
			} else { 
				
				session.setAttribute("user", update);
				
				mav.addObject("userAft", update);
				mav.setViewName("/users/updateOk");
			}
			
			return mav;
		}
		
		//유저정보 삭제
		@RequestMapping(value="/deleteUser", method=RequestMethod.GET)
		public ModelAndView deleteUser(HttpServletRequest request, Model model) {
			model.addAttribute("user", new UserVO());
			
			HttpSession session = request.getSession();
			UserVO user = (UserVO) session.getAttribute("user");

			ModelAndView mav = new ModelAndView();
			mav.addObject("user", user);

			mav.setViewName("/users/deleteUser");

			return mav;
		}
		
		@RequestMapping(value = "/deleteAction", method = RequestMethod.POST)
		public String deleteAction(UserVO user, HttpSession session, RedirectAttributes rttr) {
			
//			String inputPass = user.getPassword();
//			String pass = passEncoder.encode(inputPass);
//			user.setPassword(pass);
			
			int result = userService.deleteUser(user);
			
			if(result == 0)
				return "/users/deleteUser";
			
			session.invalidate();
			return "redirect:/";
		}
		
		//아이디 중복검사
		@ResponseBody
		@RequestMapping(value = "/idCheck", method = RequestMethod.POST)
		public int idCheck(HttpServletRequest request) throws Exception {
		 logger.info("중복체크");
		 String id = request.getParameter("id");
		 System.out.println(id);
		 int idCheck =  userService.idCheck(id);
		 
		 return idCheck;
		}
		
}
