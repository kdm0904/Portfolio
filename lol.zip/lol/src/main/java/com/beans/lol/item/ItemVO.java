package com.beans.lol.item;

public class ItemVO {
	private String item;
	private int hp;
	private double hpRecovery;
	private int hpRecovery5s;
	private int mp;
	private double mpRecovery;
	private int mpRecovery5s;
	private int attack;
	private double attackSpeed;
	private int defense;
	private int magicDefense;
	private int spell;
	private double coolDown;
	private int speed;
	private double absorbHp;
	private String passiveEffect;
	private String activeEffect;
	
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public int getHp() {
		return hp;
	}
	public void setHp(int hp) {
		this.hp = hp;
	}
	public double getHpRecovery() {
		return hpRecovery;
	}
	public void setHpRecovery(double hpRecovery) {
		this.hpRecovery = hpRecovery;
	}
	public int getHpRecovery5s() {
		return hpRecovery5s;
	}
	public void setHpRecovery5s(int hpRecovery5s) {
		this.hpRecovery5s = hpRecovery5s;
	}
	public int getMp() {
		return mp;
	}
	public void setMp(int mp) {
		this.mp = mp;
	}
	public double getMpRecovery() {
		return mpRecovery;
	}
	public void setMpRecovery(double mpRecovery) {
		this.mpRecovery = mpRecovery;
	}
	public int getMpRecovery5s() {
		return mpRecovery5s;
	}
	public void setMpRecovery5s(int mpRecovery5s) {
		this.mpRecovery5s = mpRecovery5s;
	}
	public int getAttack() {
		return attack;
	}
	public void setAttack(int attack) {
		this.attack = attack;
	}
	public double getAttackSpeed() {
		return attackSpeed;
	}
	public void setAttackSpeed(double attackSpeed) {
		this.attackSpeed = attackSpeed;
	}
	public int getDefense() {
		return defense;
	}
	public void setDefense(int defense) {
		this.defense = defense;
	}
	public int getMagicDefense() {
		return magicDefense;
	}
	public void setMagicDefense(int magicDefense) {
		this.magicDefense = magicDefense;
	}
	public int getSpell() {
		return spell;
	}
	public void setSpell(int spell) {
		this.spell = spell;
	}
	public double getCoolDown() {
		return coolDown;
	}
	public void setCoolDown(double coolDown) {
		this.coolDown = coolDown;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public double getAbsorbHp() {
		return absorbHp;
	}
	public void setAbsorbHp(double absorbHp) {
		this.absorbHp = absorbHp;
	}
	public String getPassiveEffect() {
		return passiveEffect;
	}
	public void setPassiveEffect(String passiveEffect) {
		this.passiveEffect = passiveEffect;
	}
	public String getActiveEffect() {
		return activeEffect;
	}
	public void setActiveEffect(String activeEffect) {
		this.activeEffect = activeEffect;
	}
	
	
	
	
}
