package com.beans.lol.item.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.beans.lol.item.ItemVO;
import com.beans.lol.common.JDBCUtil;
import java.sql.SQLException;

@Repository("itemDAO")
public class ItemDAO {
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	public ItemVO getItem(ItemVO ivo) {
		ItemVO item = null;
		try {
			conn = JDBCUtil.getConnection();
			String sql ="select*from item where item = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, ivo.getItem());
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				item = new ItemVO();
				
				item.setItem(rs.getString("item"));
				item.setHp(rs.getInt("hp"));
				item.setHpRecovery(rs.getDouble("hprecovery"));
				item.setHpRecovery5s(rs.getInt("hprecovery5s"));
				item.setMp(rs.getInt("mp"));
				item.setMpRecovery(rs.getDouble("mprecovery"));
				item.setMpRecovery5s(rs.getInt("mprecovery5s"));
				item.setAttack(rs.getInt("attack"));
				item.setAttackSpeed(rs.getDouble("attackspeed"));
				item.setDefense(rs.getInt("defense"));
				item.setMagicDefense(rs.getInt("magicdefense"));
				item.setSpell(rs.getInt("spell"));
				item.setCoolDown(rs.getDouble("cooldown"));
				item.setSpeed(rs.getInt("speed"));
				item.setAbsorbHp(rs.getDouble("absorbhp"));
				item.setPassiveEffect(rs.getString("passiveeffect"));
				item.setActiveEffect(rs.getString("activeeffect"));
			}
				
			
		}	catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		return item;
	}	
}
