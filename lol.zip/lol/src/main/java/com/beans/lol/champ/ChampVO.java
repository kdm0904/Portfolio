package com.beans.lol.champ;

public class ChampVO {
	private String champ;
	private double hp;
	private double hprecovery;
	private double resources;
	private double resourcesrecovery;
	private double attack;
	private double attackspeed;
	private double defense;
	private double magicdefense;
	private int range;
	private int speed;
	private double spell;
	
	public ChampVO() {
		
	}
	
	
	public ChampVO(String champ, double hp, double hprecovery, double resources, double resourcesrecovery,
			double attack, double attackspeed, double defense, double magicdefense, int range, int speed,
			double spell) {
		super();
		this.champ = champ;
		this.hp = hp;
		this.hprecovery = hprecovery;
		this.resources = resources;
		this.resourcesrecovery = resourcesrecovery;
		this.attack = attack;
		this.attackspeed = attackspeed;
		this.defense = defense;
		this.magicdefense = magicdefense;
		this.range = range;
		this.speed = speed;
		this.spell = spell;
	}


	public String getChamp() {
		return champ;
	}
	public void setChamp(String champ) {
		this.champ = champ;
	}
	public double getHp() {
		return hp;
	}
	public void setHp(double hp) {
		this.hp = hp;
	}
	public double getHprecovery() {
		return hprecovery;
	}
	public void setHprecovery(double hprecovery) {
		this.hprecovery = hprecovery;
	}
	public double getResources() {
		return resources;
	}
	public void setResources(double resources) {
		this.resources = resources;
	}
	public double getResourcesrecovery() {
		return resourcesrecovery;
	}
	public void setResourcesrecovery(double resourcesrecovery) {
		this.resourcesrecovery = resourcesrecovery;
	}
	public double getAttack() {
		return attack;
	}
	public void setAttack(double attack) {
		this.attack = attack;
	}
	public double getAttackspeed() {
		return attackspeed;
	}
	public void setAttackspeed(double attackspeed) {
		this.attackspeed = attackspeed;
	}
	public double getDefense() {
		return defense;
	}
	public void setDefense(double defense) {
		this.defense = defense;
	}
	public double getMagicdefense() {
		return magicdefense;
	}
	public void setMagicdefense(double magicdefense) {
		this.magicdefense = magicdefense;
	}
	public int getRange() {
		return range;
	}
	public void setRange(int range) {
		this.range = range;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public double getSpell() {
		return spell;
	}
	public void setSpell(double spell) {
		this.spell = spell;
	}
}
