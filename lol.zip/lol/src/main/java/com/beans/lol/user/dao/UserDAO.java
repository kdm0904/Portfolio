package com.beans.lol.user.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.stereotype.Repository;

import com.beans.lol.common.JDBCUtil;
import com.beans.lol.user.UserVO;

@Repository("userDAO")
public class UserDAO {
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	public int join(UserVO user) {
		
		int result = 0;
		try {
			
			conn = JDBCUtil.getConnection();
			String sql ="insert into user values(?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getId());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getNickName());
			pstmt.setString(4, user.getName());
			pstmt.setString(5, user.geteMail());
			result = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		return result;
	}
	
	public UserVO login(UserVO user) {
		UserVO userData = null;
		
		try {
			
			conn = JDBCUtil.getConnection();
			String sql ="select * from user where id=? and password=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getId());
			pstmt.setString(2, user.getPassword());
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				userData = new UserVO();
				userData.setId(rs.getString("id"));
				userData.setPassword(rs.getString("password"));
				userData.setNickName(rs.getString("nickname"));
				userData.setName(rs.getString("name"));
				userData.seteMail(rs.getString("email"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		return userData;
	}
	
	public int update(UserVO user) {

		int result = 0;
		try {

			conn = JDBCUtil.getConnection();
			String sql ="update user set password=?, nickname=?, name=?, email=? where id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getPassword());
			pstmt.setString(2, user.getNickName());
			pstmt.setString(3, user.getName());
			pstmt.setString(4, user.geteMail());
			pstmt.setString(5, user.getId());
			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		return result;
	}
	
	public int delete(UserVO user) {
			
			int result = 0;
			
			try {
				
				conn = JDBCUtil.getConnection();
				String sql = "delete from user where id=? and password=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, user.getId());
				pstmt.setString(2, user.getPassword());
				result = pstmt.executeUpdate();
				
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JDBCUtil.close(rs, pstmt, conn);
			}
			
			return result;
			
		}

	public int idCheck(String id) {
		UserVO userData = null;
		int result = 0;
		try {

			conn = JDBCUtil.getConnection();
			String sql ="select id from user where id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				userData = new UserVO();
				userData.setId(rs.getString("id"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		
		if(userData!= null) {
			result=1;
		} else {
			result=0;
		}
		return result;
	}
	
	//보안화된 로그인
	public UserVO loginBcrypt(UserVO user) {
		UserVO userData = null;
		
		try {
			
			conn = JDBCUtil.getConnection();
			String sql ="select * from user where id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getId());
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				userData = new UserVO();
				userData.setId(rs.getString("id"));
				userData.setPassword(rs.getString("password"));
				userData.setNickName(rs.getString("nickname"));
				userData.setName(rs.getString("name"));
				userData.seteMail(rs.getString("email"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		return userData;
	}
	
}
