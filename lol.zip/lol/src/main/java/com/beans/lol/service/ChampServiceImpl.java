package com.beans.lol.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.beans.lol.champ.ChampVO;
import com.beans.lol.champ.dao.ChampDAO;

@Service("champService")
public class ChampServiceImpl implements ChampService{
	@Autowired
	private ChampDAO champDAO;
	
	@Override
	public ChampVO getChamp(ChampVO cvo) {
		// TODO Auto-generated method stub
		return champDAO.getChamp(cvo);
	}


}
