package com.beans.lol.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.beans.lol.item.ItemVO;
import com.beans.lol.item.dao.ItemDAO;

@Service("itemService")
public class ItemServiceImpl implements ItemService{
	@Autowired
	private ItemDAO itemDAO;
	
	@Override
	public ItemVO getItem(ItemVO ivo) {
		return itemDAO.getItem(ivo);
	}
}
