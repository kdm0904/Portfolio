package com.beans.lol.service;

import com.beans.lol.champ.ChampVO;

public interface ChampService {
	ChampVO getChamp(ChampVO cvo);
}
