package com.beans.lol.service;

import com.beans.lol.item.ItemVO;

public interface ItemService {
	ItemVO getItem(ItemVO ivo);
}
