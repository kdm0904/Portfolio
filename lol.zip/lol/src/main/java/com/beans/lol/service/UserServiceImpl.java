package com.beans.lol.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.beans.lol.user.dao.UserDAO;
import com.beans.lol.user.UserVO;

@Service("userService")
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserDAO userDAO;
	
	//회원가입
	@Override
	public int join(UserVO user) {
		// TODO Auto-generated method stub
		return userDAO.join(user);
	}
	
	//로그인
	@Override
	public UserVO login(UserVO user) {
		// TODO Auto-generated method stub
		return userDAO.login(user);
		
		
	}
	
	//유저정보 업데이트
	@Override
	public UserVO update(UserVO user) {
		// TODO Auto-generated method stub
		int result = userDAO.update(user);
		
		if(result==0) {
			System.out.println("Update Fail!!");
			return null;
		} else {
			System.out.println("Update Success!!");
		}
		
		return user;
	}
	
	//유저정보 삭제
	@Override
	public int deleteUser(UserVO user) {
		// TODO Auto-generated method stub
		
		int result = userDAO.delete(user);
		
		if(result==0) {
			System.out.println("delete Failed");	
		} else {
			System.out.println("delete Success!!");
		}
		
		return result;
	}

	//아이디 중복 확인
	@Override
	public int idCheck(String id) {
		// TODO Auto-generated method stub
		return userDAO.idCheck(id);
	}

	
	
	
	

	

	

}
