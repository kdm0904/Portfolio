package com.beans.lol.service;

import com.beans.lol.user.UserVO;

public interface UserService {
	
	public int join(UserVO user);
	
	UserVO login(UserVO user);
	
	UserVO update(UserVO user);
	
	public int deleteUser(UserVO user);
	
	public int idCheck(String id);
}
